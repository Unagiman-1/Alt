window.ysdk = null;
window.ysdkReady = Promise.resolve(null);
window.yandexGameLanguage = 'ru';
window.__yandexGameReadyRequested = false;
window.__yandexGameplayRequested = false;

window.yandexGameReady = function () {
	window.__yandexGameReadyRequested = true;
	if (window.ysdk) window.ysdk.features?.LoadingAPI?.ready();
};
window.yandexGameplayStart = function () {
	window.__yandexGameplayRequested = true;
	if (window.ysdk) window.ysdk.features?.GameplayAPI?.start();
};
window.yandexGameplayStop = function () {
	window.__yandexGameplayRequested = false;
	if (window.ysdk) window.ysdk.features?.GameplayAPI?.stop();
};
window.yandexRequestFullscreen = function () {
	var request = window.ysdk?.screen?.fullscreen?.request;
	if (typeof request === 'function') {
		try {
			var result = request.call(window.ysdk.screen.fullscreen);
			if (result && typeof result.catch === 'function') result.catch(function () {});
		} catch (error) {
			console.info('Fullscreen request was not accepted:', error);
		}
	}
};
window.yandexShowRewardedAd = function () {
	if (!window.ysdk || !window.ysdk.adv) return false;
	try {
		window.ysdk.adv.showRewardedVideo({
			callbacks: {
				onRewarded: function () { window.godotYandexReward?.(); },
				onClose: function (wasShown) { window.godotYandexAdClosed?.(wasShown); },
				onError: function (error) { window.godotYandexAdError?.(String(error)); }
			}
		});
		return true;
	} catch (error) {
		window.godotYandexAdError?.(String(error));
		return false;
	}
};

window.initYandexSDK = function () {
	window.ysdkReady = YaGames.init().then(function (sdk) {
		window.ysdk = sdk;
		window.yandexGameLanguage = String(sdk.environment?.i18n?.lang || 'ru').toLowerCase();
		sdk.on('game_api_pause', function () { window.godotYandexPause?.(); });
		sdk.on('game_api_resume', function () { window.godotYandexResume?.(); });
		if (window.__yandexGameReadyRequested) sdk.features?.LoadingAPI?.ready();
		if (window.__yandexGameplayRequested) sdk.features?.GameplayAPI?.start();
		return sdk;
	}).catch(function (error) {
		console.warn('Yandex Games SDK initialization failed:', error);
		return null;
	});
};

window.addEventListener('contextmenu', function (event) { event.preventDefault(); });
