"""Генерация простых звуковых эффектов в WAV (stdlib)."""
import math, random, struct, wave, os

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "audio")
os.makedirs(OUT, exist_ok=True)


def save(name, samples):
    path = os.path.join(OUT, name + ".wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 30000)) for s in samples)
        w.writeframes(frames)
    print(name, len(samples) / SR)


def tone(freq, dur, vol=0.5, slide=0.0, wave_type="sine"):
    n = int(SR * dur)
    out = []
    for i in range(n):
        t = i / SR
        f = freq + slide * t
        ph = 2 * math.pi * f * t
        v = math.sin(ph) if wave_type == "sine" else (1 if math.sin(ph) > 0 else -1) * 0.6
        out.append(v * vol * (1 - i / n))
    return out


def noise(dur, vol=0.5, lowpass=0.3):
    n = int(SR * dur)
    out = []
    last = 0.0
    for i in range(n):
        white = random.uniform(-1, 1)
        last = last + lowpass * (white - last)
        out.append(last * vol * (1 - i / n) ** 1.5)
    return out


def mix(*tracks):
    n = max(len(t) for t in tracks)
    return [sum(t[i] if i < len(t) else 0 for t in tracks) for i in range(n)]


save("shoot", tone(700, 0.09, 0.35, slide=-900, wave_type="square"))
save("hit", noise(0.06, 0.4, 0.5))
save("coin", mix(tone(990, 0.07, 0.3), [0] * 1200 + tone(1320, 0.12, 0.3)))
save("splash", noise(0.35, 0.55, 0.12))
save("chord", mix(tone(196, 0.5, 0.3, wave_type="square"),
                   tone(247, 0.5, 0.25, wave_type="square"),
                   tone(294, 0.5, 0.25, wave_type="square")))
save("boom", noise(0.5, 0.8, 0.06))
save("click", tone(1200, 0.04, 0.25))
save("hurt", tone(160, 0.2, 0.5, slide=-60, wave_type="square"))
save("win", mix(tone(523, 0.15, 0.3), [0] * 2500 + tone(659, 0.15, 0.3),
                [0] * 5000 + tone(784, 0.3, 0.3)))
save("lose", mix(tone(392, 0.25, 0.3), [0] * 4000 + tone(330, 0.25, 0.3),
                 [0] * 8000 + tone(262, 0.5, 0.3)))
