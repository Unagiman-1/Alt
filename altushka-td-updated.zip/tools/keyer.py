"""Хромакей по мадженте + деспилл + обрезка по силуэту."""
import numpy as np
from PIL import Image


def key_out(src, dst, target_h=None):
    im = Image.open(src).convert("RGB")
    a = np.asarray(im).astype(np.float32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    # расстояние до мадженты: фон там, где R и B высокие, а G низкий
    magenta_score = np.minimum(r, b) - g
    alpha = np.clip((magenta_score - 40) / 70, 0, 1)
    alpha = 1.0 - alpha  # 1 = объект
    # деспилл: у пикселей объекта убираем маджентный оттенок
    rr = np.where((r > g) & (b > g), np.maximum(g, np.minimum(r, b) * 0.9), r)
    bb = np.where((r > g) & (b > g), np.maximum(g, np.minimum(r, b) * 0.9), b)
    out = np.dstack([rr, g, bb, alpha * 255]).astype(np.uint8)
    img = Image.fromarray(out, "RGBA")
    bbox = img.getchannel("A").getbbox()
    if bbox:
        img = img.crop(bbox)
    if target_h:
        w = max(1, round(img.width * target_h / img.height))
        img = img.resize((w, target_h), Image.LANCZOS)
    img.save(dst)
    return img.size


def largest_component(src_rgba):
    """Оставляет только самую большую связную компоненту (герой без тапка)."""
    from scipy import ndimage
    alpha = np.asarray(src_rgba.getchannel("A")) > 40
    lab, n = ndimage.label(alpha)
    if n <= 1:
        return src_rgba, None
    sizes = ndimage.sum(alpha, lab, range(1, n + 1))
    keep = 1 + int(np.argmax(sizes))
    out = np.asarray(src_rgba).copy()
    out[(lab != keep) & (lab != 0)] = 0
    rest = np.asarray(src_rgba).copy()
    rest[lab != (1 + int(np.argsort(sizes)[-2])) if n > 1 else (lab == keep)] = 0
    return Image.fromarray(out, "RGBA"), Image.fromarray(rest, "RGBA")
