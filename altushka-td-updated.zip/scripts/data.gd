extends RefCounted
## Статические данные: враги, волны, магазин, усиления, наряды.

const ENEMIES := {
	"normal": {"hp": 30.0, "speed": 56.0, "reward": 6, "dmg": 4.0, "tex": "td_skuf_normal"},
	"fast": {"hp": 20.0, "speed": 108.0, "reward": 8, "dmg": 3.0, "tex": "td_skuf_fast"},
	"fat": {"hp": 130.0, "speed": 33.0, "reward": 14, "dmg": 8.0, "tex": "td_skuf_fat"},
	"scooter": {"hp": 26.0, "speed": 152.0, "reward": 10, "dmg": 3.0, "tex": "td_skuf_scooter"},
	"boss": {"hp": 950.0, "speed": 27.0, "reward": 150, "dmg": 20.0, "tex": "td_skuf_boss"},
	"armored": {"hp": 65.0, "speed": 43.0, "reward": 11, "dmg": 5.0, "armor": 3.0, "tex": "td_skuf_fat"},
	"regen": {"hp": 42.0, "speed": 50.0, "reward": 10, "dmg": 4.0, "regen": 3.0, "tex": "td_skuf_normal"},
}

const ENEMY_NAMES := {
	"normal": "Скуф", "fast": "Скуф в спортивках", "fat": "Толстый скуф",
	"scooter": "Скуф на самокате", "boss": "ГЛАВНЫЙ СКУФ",
	"armored": "Скуф в каске", "regen": "Скуф с энергетиком",
}

const TOWER_TYPES := {
	"girlfriend": {"name": "Подружка", "cost": 60, "dmg": 7.0, "rate": 2.2, "range": 300.0,
		"desc": "Быстро кидает подушки"},
	"speaker": {"name": "Колонка", "cost": 80, "dmg": 2.0, "rate": 1.0, "range": 200.0,
		"desc": "Бас наносит урон и замедляет скуфов"},
	"granny": {"name": "Бабушка", "cost": 110, "dmg": 26.0, "rate": 0.55, "range": 310.0,
		"desc": "Метко швыряет тяжёлые сумки"},
	"cat": {"name": "Котик с рогаткой", "cost": 90, "dmg": 5.0, "rate": 3.4, "range": 270.0,
		"desc": "Очень быстро стреляет из рогатки"},
	"kiosk": {"name": "Киоск с газировкой", "cost": 85, "dmg": 0.0, "rate": 0.0, "range": 0.0, "desc": "Приносит 8 монет каждые 8 секунд"},
	"patrol": {"name": "Дежурный пост", "cost": 105, "dmg": 0.0, "rate": 0.0, "range": 285.0, "desc": "Сосед задерживает скуфов на дороге"},

}

const OUTFITS := [
	{"id": "goth", "name": "Готика", "cost": 0, "desc": "Классика жанра", "bonus": {}, "tint": Color(1, 1, 1)},
	{"id": "punk", "name": "Панк-рок", "cost": 150, "desc": "+15% к урону", "bonus": {"dmg": 0.15}, "tint": Color(0.85, 1.15, 0.9)},
	{"id": "neon", "name": "Неон", "cost": 300, "desc": "+15% к скорострельности", "bonus": {"rate": 0.15}, "tint": Color(1.15, 0.85, 1.25)},
	{"id": "queen", "name": "Королева двора", "cost": 600, "desc": "+25% монет со скуфов", "bonus": {"coins": 0.25}, "tint": Color(1.25, 1.08, 0.72)},
]

const BUFFS := [
	{"id": "dmg", "name": "Тапки потяжелее", "desc": "+12% к урону"},
	{"id": "rate", "name": "Кофеин", "desc": "+10% к скорострельности"},
	{"id": "coins", "name": "Мелочь по карманам", "desc": "+20% монет в этом забеге"},
	{"id": "hp", "name": "Подлатать балкон", "desc": "+20 к макс. прочности и ремонт 20"},
	{"id": "ability", "name": "Громче!", "desc": "+25% к урону способностей"},
	{"id": "cdr", "name": "Энергетик", "desc": "Способности перезаряжаются на 15% быстрее"},
	{"id": "heal", "name": "Перекур", "desc": "Восстановить 35 прочности балкона"},
]


static func build_wave(n: int) -> Array:
	var q: Array = []
	var normals := 4 + 2 * n
	for i in normals:
		q.append("normal")
	if n >= 2:
		for i in n:
			q.append("fast")
	if n >= 3:
		for i in maxi(1, n / 2):
			q.append("fat")
	if n >= 4:
		for i in maxi(1, n / 2):
			q.append("scooter")
	if n >= 3:
		for i in maxi(1, n / 3):
			q.append("armored")
	if n >= 4:
		for i in maxi(1, n / 4):
			q.append("regen")
	if n % 5 == 0:
		q.append("boss")
		for i in 3:
			q.append("normal")
	q.shuffle()
	if n % 5 == 0:
		# босс идёт ближе к концу волны
		q.erase("boss")
		q.insert(maxi(0, q.size() - 3), "boss")
	return q


static func hp_scale(n: int) -> float:
	return pow(1.17, float(n - 1))


static func speed_scale(n: int) -> float:
	return minf(1.45, 1.0 + 0.02 * float(n - 1))

# Многовходовая схема карты (1280x720): три исходных прохода и дополнительный открытый обход слева; ступени лестницы не пересекаются маршрутами.
# Все подходы сходятся на общей дороге и используют общий финальный коридор к подъезду.
const ROUTES := [
	[Vector2(-25, 465), Vector2(110, 465), Vector2(220, 470), Vector2(315, 485), Vector2(405, 480), Vector2(475, 460), Vector2(525, 435), Vector2(565, 395), Vector2(610, 350), Vector2(665, 325), Vector2(755, 320), Vector2(850, 340), Vector2(940, 340), Vector2(1015, 300), Vector2(1070, 250), Vector2(1105, 190), Vector2(1120, 105)],
	[Vector2(125, 325), Vector2(190, 340), Vector2(255, 365), Vector2(310, 400), Vector2(370, 440), Vector2(430, 460), Vector2(490, 445), Vector2(545, 405), Vector2(590, 360), Vector2(650, 330), Vector2(740, 325), Vector2(850, 340), Vector2(940, 340), Vector2(1015, 300), Vector2(1070, 250), Vector2(1105, 190), Vector2(1120, 105)],
	[Vector2(-20, 35), Vector2(35, 115), Vector2(75, 200), Vector2(110, 275), Vector2(145, 325), Vector2(205, 345), Vector2(270, 380), Vector2(330, 415), Vector2(395, 450), Vector2(455, 460), Vector2(505, 435), Vector2(555, 395), Vector2(610, 350), Vector2(665, 325), Vector2(755, 320), Vector2(850, 340), Vector2(940, 340), Vector2(1015, 300), Vector2(1070, 250), Vector2(1105, 190), Vector2(1120, 105)],
	[Vector2(-25, 405), Vector2(40, 407), Vector2(105, 418), Vector2(170, 438), Vector2(235, 465), Vector2(315, 485), Vector2(405, 480), Vector2(475, 460), Vector2(525, 435), Vector2(565, 395), Vector2(610, 350), Vector2(665, 325), Vector2(755, 320), Vector2(850, 340), Vector2(940, 340), Vector2(1015, 300), Vector2(1070, 250), Vector2(1105, 190), Vector2(1120, 105)],
]
const PATH := ROUTES[0]
const SPAWNS := [Vector2(-15, 465), Vector2(125, 325), Vector2(-10, 35), Vector2(-25, 405)]
# Purchasable sofas stand crosswise across the two road chokepoints.
const BARRIER_POINTS := [Vector2(525, 435), Vector2(850, 340)]
const BARRIER_MAX_HP := [65.0, 65.0]
const BARRIER_COST := 45

# Башенные площадки: просторные и расположенные по краям дорожной сети.
const PADS := [
	Vector2(270, 235), Vector2(555, 215), Vector2(930, 185), Vector2(1050, 160),
	Vector2(255, 600), Vector2(600, 625), Vector2(770, 555), Vector2(1150, 365),
]

const HERO_POS := Vector2(990, 225)
const HERO_RANGE := 430.0
