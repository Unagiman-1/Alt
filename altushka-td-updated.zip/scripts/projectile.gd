extends Node2D
## Снаряд: тапок (или подушка) летит в скуфа с самонаведением.

var target: Node2D = null
var target_pos := Vector2.ZERO
var speed := 620.0
var damage := 10.0
var game: Node = null
var alive := true

var sprite: Sprite2D
var spin := 9.0


func setup(tex: Texture2D, from: Vector2, p_target: Node2D, p_damage: float, p_game: Node, tint := Color.WHITE) -> void:
	position = from
	target = p_target
	damage = p_damage
	game = p_game
	if target:
		target_pos = target.position + Vector2(0, -30)
	sprite = Sprite2D.new()
	sprite.texture = tex
	sprite.modulate = tint
	add_child(sprite)


func _process(delta: float) -> void:
	if not alive:
		return
	if target and is_instance_valid(target) and not target.dead:
		target_pos = target.position + Vector2(0, -30)
	var to := target_pos - position
	if to.length() < 26.0:
		alive = false
		if target and is_instance_valid(target) and not target.dead:
			if game and game.has_method("play_sfx"):
				game.play_sfx("hit")
			target.take_damage(damage)
		queue_free()
		return
	position += to.normalized() * speed * delta
	sprite.rotation += spin * delta
	if position.x < -80 or position.x > 1400 or position.y < -80 or position.y > 800:
		queue_free()
