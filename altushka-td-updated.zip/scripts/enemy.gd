extends Node2D

const Data = preload("res://scripts/data.gd")
## Скуф: идёт по маршруту двора к подъезду, у двери ломится в неё.

var kind := "normal"
var hp := 30.0
var max_hp := 30.0
var speed := 56.0
var reward := 6
var dmg := 4.0
var armor := 0.0
var regen := 0.0
var game: Node = null

var path: Array = []  # Array[Vector2]
var wp := 0
var progress := 0.0  # пройдено пикселей — для прицеливания «по первому»
var lane_offsets: Array[Vector2] = []
var slow_until := 0.0
var slow_factor := 1.0
var attacking := false
var barrier_index := -1
var guard_target: Node2D = null
var attack_timer := 0.0
var dead := false
var flash := 0.0
var walk_phase := 0.0
var t_alive := 0.0
var phase := 0.0
var squash := 0.0

var sprite: Sprite2D


func setup(p_kind: String, stats: Dictionary, tex: Texture2D, p_game: Node, hp_mult: float, speed_mult: float, p_path: Array) -> void:
	kind = p_kind
	max_hp = float(stats["hp"]) * hp_mult
	hp = max_hp
	speed = float(stats["speed"]) * speed_mult * randf_range(0.92, 1.08)
	reward = int(stats["reward"])
	dmg = float(stats["dmg"])
	armor = float(stats.get("armor", 0.0))
	regen = float(stats.get("regen", 0.0))
	game = p_game
	path = p_path
	phase = randf() * TAU
	_build_lane_offsets()
	position = path[0] + lane_offsets[0]
	sprite = Sprite2D.new()
	sprite.texture = tex
	sprite.offset = Vector2(0, -tex.get_height() / 2.0)
	add_child(sprite)


func _build_lane_offsets() -> void:
	lane_offsets.clear()
	if path.is_empty():
		return
	var last := path.size() - 1
	var spread := 32.0
	if kind == "boss": spread = 10.0
	elif kind == "fat" or kind == "armored": spread = 22.0
	var previous := 0.0
	for i in path.size():
		var before: Vector2 = path[maxi(0, i - 1)]
		var after: Vector2 = path[mini(last, i + 1)]
		var tangent := (after - before).normalized()
		if tangent == Vector2.ZERO: tangent = Vector2.RIGHT
		var normal := Vector2(-tangent.y, tangent.x)
		var desired := randf_range(-spread, spread)
		previous = lerpf(previous, desired, 0.4)
		var fade := 1.0
		if i < 3: fade = minf(fade, float(i) / 3.0)
		if i > last - 3: fade = minf(fade, float(last - i) / 3.0)
		lane_offsets.append(normal * previous * fade)


func _target_point() -> Vector2:
	return path[mini(wp, path.size() - 1)] + lane_offsets[mini(wp, lane_offsets.size() - 1)]


func _process(delta: float) -> void:
	if dead:
		return
	t_alive += delta
	walk_phase += delta * speed * 0.09
	if regen > 0.0 and hp > 0.0:
		hp = minf(max_hp, hp + regen * delta)
	# pseudo-Live2D: дыхание + покачивание + восстановление после удара
	if squash > 0.0:
		squash -= delta
	var breath := 1.0 + 0.02 * sin(t_alive * 2.1 + phase)
	if squash > 0.0:
		var k := clampf(squash / 0.12, 0.0, 1.0)
		sprite.scale = Vector2(1.0 + 0.16 * k, (1.0 - 0.13 * k) * (1.04 if kind == "boss" else 1.10))
	else:
		sprite.scale = Vector2(2.0 - breath, breath * (1.04 if kind == "boss" else 1.10))
	sprite.rotation = sin(t_alive * 1.6 + phase) * 0.03
	var now := Time.get_ticks_msec() / 1000.0
	var f := slow_factor if now < slow_until else 1.0
	if not attacking:
		var tp := _target_point()
		var to := tp - position
		if game.has_method("get_guard_blocker"):
			guard_target = game.get_guard_blocker(self)
			if guard_target != null:
				attacking = true
				attack_timer = 0.0
		if not attacking:
			for bi in range(game.barrier_hp.size()):
				if game.barrier_hp[bi] > 0.0 and position.distance_to(Data.BARRIER_POINTS[bi]) < 48.0:
					barrier_index = bi
					attacking = true
					break
		if attacking:
			if guard_target != null:
				attack_timer -= delta
				if attack_timer <= 0.0:
					attack_timer = 0.7
					if not is_instance_valid(guard_target) or game.damage_guard(guard_target, dmg):
						guard_target = null
						attacking = false
				return
			attack_timer -= delta
			if attack_timer <= 0.0:
				attack_timer = 0.7
				if game.damage_barrier(barrier_index, dmg):
					attacking = false
					barrier_index = -1
			return
		var step := speed * f * delta
		if to.length() <= step:
			position = tp
			progress += to.length()
			wp += 1
			if wp >= path.size():
				attacking = true
		else:
			position += to.normalized() * step
			progress += step
		sprite.position.y = -absf(sin(walk_phase)) * 3.0
	else:
		if guard_target != null:
			if not is_instance_valid(guard_target):
				guard_target = null
				attacking = false
			else:
				attack_timer -= delta
				sprite.position.y = -absf(sin(walk_phase * 2.4)) * 2.0
				if attack_timer <= 0.0:
					attack_timer = 0.7
					if game.damage_guard(guard_target, dmg):
						guard_target = null
						attacking = false
				return
		if attacking and barrier_index >= 0:
			attack_timer -= delta
			sprite.position.y = -absf(sin(walk_phase * 2.4)) * 2.0
			if attack_timer <= 0.0:
				attack_timer = 0.7
				if game.damage_barrier(barrier_index, dmg):
					barrier_index = -1
					attacking = false
		elif attacking:
			attack_timer -= delta
			sprite.position.y = -absf(sin(walk_phase * 2.4)) * 2.0
			if attack_timer <= 0.0:
				attack_timer = 0.6
				if game and game.has_method("damage_tower"):
					game.damage_tower(dmg)
	z_index = 100 + int(position.y)
	if flash > 0.0:
		flash -= delta
		sprite.modulate = Color(2.2, 0.6, 0.6) if flash > 0.0 else Color.WHITE


func take_damage(amount: float, knockback := 0.0) -> void:
	if dead:
		return
	var actual := maxf(1.0, amount - armor)
	hp -= actual
	if game and game.has_method("_float_text"):
		game._float_text(position + Vector2(randf_range(-15, 15), -62), "-%d" % int(actual), Color(1.0, 0.92, 0.72), 15)
	flash = 0.09
	squash = 0.12
	queue_redraw()
	if knockback > 0.0 and not attacking and wp > 0:
		# отбрасываем назад вдоль маршрута
		var back: Vector2 = (path[wp - 1] + lane_offsets[wp - 1] - position).normalized()
		if back != Vector2.ZERO:
			position += back * knockback * 0.4
			progress = maxf(0.0, progress - knockback * 0.4)
	if hp <= 0.0:
		dead = true
		if game and game.has_method("on_enemy_killed"):
			game.on_enemy_killed(self)
		# анимация смерти: скуф «сдувается» и тает
		var tw := create_tween()
		tw.set_parallel(true)
		tw.tween_property(self, "scale", Vector2(0.55, 0.55), 0.22)
		tw.tween_property(self, "rotation", 0.45, 0.22)
		tw.tween_property(self, "modulate:a", 0.0, 0.22)
		tw.chain().tween_callback(queue_free)


func apply_slow(factor: float, duration: float) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	slow_factor = minf(slow_factor, factor) if now < slow_until else factor
	slow_until = now + duration


func _draw() -> void:
	if dead or not sprite or not sprite.texture:
		return
	var w := 46.0
	var h := float(sprite.texture.get_height())
	var y := -h - 12.0
	draw_rect(Rect2(-w / 2, y, w, 6), Color(0, 0, 0, 0.55))
	var frac := clampf(hp / max_hp, 0.0, 1.0)
	var col := Color(0.45, 0.95, 0.4) if frac > 0.35 else Color(0.98, 0.4, 0.3)
	draw_rect(Rect2(-w / 2 + 1, y + 1, (w - 2) * frac, 4), col)
