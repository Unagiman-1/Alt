extends Node2D
## «АЛЬТУШКА: ОБОРОНА БАШНИ» — TD видом сверху: скуфы идут по дороге
## двора к подъезду, Альтушка обстреливает их с крыши, игрок строит
## башенки на пятачках в любой момент и жмёт способности.

const Data = preload("res://scripts/data.gd")
const Enemy = preload("res://scripts/enemy.gd")
const Projectile = preload("res://scripts/projectile.gd")

const SAVE_PATH := "user://altushka_save.json"

var tex := {}
var ui_icons := {}
var state := "menu"  # menu / prep / battle / choice / over
var wave := 0
var coins := 0
var run_coin_mult := 1.0
var tower_hp := 100.0
var tower_max_hp := 100.0
var kills := 0
var coins_earned_wave := 0

var dmg := 10.0
var fire_rate := 2.0
var ability_mult := 1.0
var cdr_mult := 1.0

var enemies: Array = []
var spawn_queue: Array = []
var spawn_timer := 0.0
var hero_timer := 0.0
var towers: Array = []  # по числу Data.PADS: null или {type, level, node, timer}
var cooldowns := {"bucket": 0.0, "chord": 0.0, "cat": 0.0}
var cat_node: Node2D = null
var cat_active := false
var cat_target: Node2D = null
var barrier_sprites: Array[Sprite2D] = []
var fx_rings: Array = []
var fx_texts: Array = []
var shop_levels := {"dmg": 0, "rate": 0, "hp": 0, "ability": 0, "cdr": 0}
var paused := false
var speed_x2 := false

var best_wave := 0
var stars := 0
var permanent_perks := {"damage": 0, "income": 0, "hp": 0}
var resident_jobs: Array[String] = ["income", "repair", "guard"]
var guard_hp_bonus := 0.0
var guard_units: Array[Dictionary] = []
var run_level := 1
var branch_choices := {}
var barrier_hp := [0.0, 0.0]
var early_call_bonus := 0.0
var tutorial_active := false
var tutorial_elapsed := 0.0
var platform_paused := false
var platform_lang_code := "ru"
var rewarded_ad_used := false
var rewarded_ad_pending := false
var rewarded_ad_claimed := false
var ad_pause_active := false
var platform_gameplay_active := false
var _js_pause_callback = null
var _js_resume_callback = null
var _js_reward_callback = null
var _js_ad_close_callback = null
var _js_ad_error_callback = null
var first_wave_protection := false
var hud_hint_panel: PanelContainer
var outfits_owned: Array = ["goth"]
var outfit_equipped := "goth"
var sound_on := true
var pending_run_save: Dictionary = {}
var save_pending := false
var save_delay := 0.0

var hero: Sprite2D
var bg: Sprite2D
var ui: CanvasLayer
var hud_wave: Label
var hud_coins: Label
var hud_hp: Label
var hud_hint: Label
var ability_btns := {}
var shop_panel: PanelContainer
var choice_panel: PanelContainer
var menu_panel: PanelContainer
var hub_panel: PanelContainer
var over_panel: PanelContainer
var slot_btns: Array = []
var tower_upgrade_btns: Array[Button] = []
var slot_popup: PanelContainer
var slot_popup_slot := -1
var slot_popup_refresh_queued := false
var anim_t := 0.0
var portrait_anim_t := 0.0
var choice_portrait_intro := 1.0
var hero_blink := 2.5
var hero_blink_t := 0.0
var portrait_box: Control
var portrait_img: TextureRect
var bubble_panel: PanelContainer
var bubble_label: Label
var mood := "idle"
var mood_t := 0.0
var say_t := 0.0
var p_blink := 3.0
var p_blink_t := 0.0
var last_panic_say := -10.0
var audio_pool: Array = []
var audio_idx := 0
var sfx := {}


func _ready() -> void:
	for i in Data.PADS.size():
		towers.append(null)
	_load_tex()
	_build_world()
	_build_audio()
	_build_ui()
	_load_save()
	_build_menu()
	_apply_audio_mute()
	_apply_outfit_visual()
	_show_menu()
	_setup_yandex_bridge()
	call_deferred("_notify_yandex_ready")


func _setup_yandex_bridge() -> void:
	if not OS.has_feature("web"):
		return
	var window: JavaScriptObject = JavaScriptBridge.get_interface("window")
	_js_pause_callback = JavaScriptBridge.create_callback(_on_yandex_pause)
	_js_resume_callback = JavaScriptBridge.create_callback(_on_yandex_resume)
	_js_reward_callback = JavaScriptBridge.create_callback(_on_yandex_rewarded)
	_js_ad_close_callback = JavaScriptBridge.create_callback(_on_yandex_ad_closed)
	_js_ad_error_callback = JavaScriptBridge.create_callback(_on_yandex_ad_error)
	window.set("godotYandexPause", _js_pause_callback)
	window.set("godotYandexResume", _js_resume_callback)
	window.set("godotYandexReward", _js_reward_callback)
	window.set("godotYandexAdClosed", _js_ad_close_callback)
	window.set("godotYandexAdError", _js_ad_error_callback)


func _notify_yandex_ready() -> void:
	if not OS.has_feature("web"):
		return
	await get_tree().process_frame
	var detected = JavaScriptBridge.eval("window.yandexGameLanguage || 'ru'")
	if detected is String:
		platform_lang_code = detected.to_lower().split("-")[0].split("_")[0]
	# Russian is the only language declared in the Yandex Games draft; fall back to it for others.
	TranslationServer.set_locale("ru" if platform_lang_code != "ru" else platform_lang_code)
	JavaScriptBridge.eval("window.yandexGameReady && window.yandexGameReady()")


func _notify_yandex_gameplay_start() -> void:
	if platform_gameplay_active or not OS.has_feature("web"):
		return
	platform_gameplay_active = true
	JavaScriptBridge.eval("window.yandexGameplayStart && window.yandexGameplayStart()")


func _notify_yandex_gameplay_stop() -> void:
	if not platform_gameplay_active or not OS.has_feature("web"):
		return
	platform_gameplay_active = false
	JavaScriptBridge.eval("window.yandexGameplayStop && window.yandexGameplayStop()")


func _request_platform_fullscreen() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval("window.yandexRequestFullscreen && window.yandexRequestFullscreen()")


func _apply_audio_mute() -> void:
	var muted := not sound_on or paused or platform_paused or ad_pause_active
	AudioServer.set_bus_mute(0, muted)
	if muted:
		for player in audio_pool:
			player.stop()


func _set_platform_paused(value: bool) -> void:
	if platform_paused == value:
		return
	platform_paused = value
	_apply_audio_mute()
	if value:
		_notify_yandex_gameplay_stop()
	elif not paused and state in ["prep", "battle", "choice"]:
		_notify_yandex_gameplay_start()


func _on_yandex_pause(_args: Array) -> void:
	_set_platform_paused(true)


func _on_yandex_resume(_args: Array) -> void:
	_set_platform_paused(false)


func _on_yandex_rewarded(_args: Array) -> void:
	rewarded_ad_claimed = true


func _on_yandex_ad_closed(_args: Array) -> void:
	if rewarded_ad_pending and rewarded_ad_claimed:
		coins += 40
		rewarded_ad_used = true
		play_sfx("coin")
		_update_hud()
		_save(true)
	rewarded_ad_pending = false
	rewarded_ad_claimed = false
	if state == "prep":
		_refresh_shop()
	ad_pause_active = false
	_apply_audio_mute()
	if not paused and not platform_paused and state in ["prep", "battle", "choice"]:
		_notify_yandex_gameplay_start()


func _on_yandex_ad_error(_args: Array) -> void:
	rewarded_ad_pending = false
	rewarded_ad_claimed = false
	ad_pause_active = false
	_apply_audio_mute()
	hud_hint.text = "Реклама сейчас недоступна. Попробуй позже."
	if not paused and not platform_paused and state in ["prep", "battle", "choice"]:
		_notify_yandex_gameplay_start()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		_save(true)
		_set_platform_paused(true)
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN:
		_set_platform_paused(false)
	elif what == NOTIFICATION_WM_SIZE_CHANGED:
		_save(true)


func _load_tex() -> void:
	for n in ["td_altushka", "tapok", "td_skuf_normal", "td_skuf_fast", "td_skuf_fat",
			"td_skuf_scooter", "td_skuf_boss", "td_girlfriend", "speaker", "td_granny", "td_cat", "cat",
			"portrait", "portrait_blink", "sofa_barrier"]:
		tex[n] = load("res://assets/art/%s.png" % n)
	tex["map1"] = load("res://assets/art/map1.jpg")
	for n in ["shoot", "hit", "coin", "splash", "chord", "boom", "click", "hurt", "win", "lose"]:
		sfx[n] = load("res://assets/audio/%s.wav" % n)
	for n in ["coins", "tower", "bucket", "music", "cat", "pause", "play", "speed", "sound", "shop", "upgrade", "repair", "outfit", "attack"]:
		ui_icons[n] = load("res://assets/ui/icons/%s.svg" % n)


func _build_world() -> void:
	bg = Sprite2D.new()
	bg.texture = tex["map1"]
	bg.centered = false
	bg.z_index = -10
	add_child(bg)
	barrier_sprites.clear()
	for i in Data.BARRIER_POINTS.size():
		var sofa := Sprite2D.new()
		sofa.texture = tex["sofa_barrier"]
		sofa.position = Data.BARRIER_POINTS[i]
		sofa.z_index = 100 + int(sofa.position.y) - 1
		sofa.scale = Vector2(0.96, 0.96)
		sofa.visible = barrier_hp[i] > 0.0
		sofa.rotation = 0.90 if i == 0 else PI / 2.0
		add_child(sofa)
		barrier_sprites.append(sofa)
	hero = Sprite2D.new()
	hero.texture = tex["td_altushka"]
	hero.position = Data.HERO_POS
	hero.offset = Vector2(0, -tex["td_altushka"].get_height() / 2.0)
	hero.scale = Vector2.ONE
	hero.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	hero.z_index = 600
	add_child(hero)


func _build_audio() -> void:
	for i in 10:
		var p := AudioStreamPlayer.new()
		add_child(p)
		audio_pool.append(p)


func play_sfx(name: String) -> void:
	if not sound_on or paused or platform_paused or not sfx.has(name):
		return
	var p: AudioStreamPlayer = audio_pool[audio_idx]
	audio_idx = (audio_idx + 1) % audio_pool.size()
	p.stream = sfx[name]
	p.pitch_scale = randf_range(0.94, 1.06)
	p.play()


# ---------- UI ----------

func _label(parent: Node, text: String, size: int, color := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_shadow_color", Color(0.015, 0.025, 0.04, 0.42))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	parent.add_child(l)
	return l


func _button(parent: Node, text: String, size := 20) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", Color(0.91, 0.94, 0.98))
	b.add_theme_color_override("font_hover_color", Color(0.98, 0.99, 1.0))
	b.add_theme_color_override("font_pressed_color", Color(0.76, 0.86, 0.94))
	b.add_theme_color_override("font_disabled_color", Color(0.55, 0.60, 0.67))
	for pair in [["normal", Color(0.13, 0.18, 0.25, 0.98), Color(0.33, 0.42, 0.54)], ["hover", Color(0.20, 0.28, 0.38, 1.0), Color(0.56, 0.68, 0.82)], ["pressed", Color(0.08, 0.12, 0.18, 1.0), Color(0.54, 0.65, 0.78)], ["disabled", Color(0.12, 0.15, 0.20, 0.86), Color(0.25, 0.30, 0.38)]]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = pair[1]
		sb.border_color = pair[2]
		sb.set_border_width_all(1)
		sb.set_corner_radius_all(8)
		sb.set_content_margin(SIDE_LEFT, 10)
		sb.set_content_margin(SIDE_RIGHT, 10)
		sb.set_content_margin(SIDE_TOP, 6)
		sb.set_content_margin(SIDE_BOTTOM, 6)
		b.add_theme_stylebox_override(str(pair[0]), sb)
	parent.add_child(b)
	return b

func _upgrade_button_style(fill: Color, border: Color, glow: bool) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(13)
	style.set_content_margin(SIDE_LEFT, 8)
	style.set_content_margin(SIDE_RIGHT, 8)
	style.set_content_margin(SIDE_TOP, 5)
	style.set_content_margin(SIDE_BOTTOM, 5)
	if glow:
		style.shadow_color = Color(1.0, 0.61, 0.12, 0.72)
		style.shadow_size = 8
		style.shadow_offset = Vector2(0, 2)
	return style


func _apply_button_icon(button: Button, key: String, max_width := 24) -> void:
	if not ui_icons.has(key):
		return
	button.icon = ui_icons[key]
	button.add_theme_constant_override("icon_max_width", max_width)
	button.icon_alignment = HORIZONTAL_ALIGNMENT_LEFT


func _icon(parent: Node, key: String, size := 24, tint := Color(0.73, 0.82, 0.92)) -> TextureRect:
	var icon := TextureRect.new()
	icon.texture = ui_icons.get(key)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.custom_minimum_size = Vector2(size, size)
	icon.modulate = tint
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(icon)
	return icon


func _hud_chip(parent: Node, text: String, color: Color, icon_key: String) -> Label:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.12, 0.18, 0.94)
	sb.border_color = Color(0.34, 0.43, 0.54, 0.9)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(8)
	sb.content_margin_left = 11
	sb.content_margin_right = 11
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	p.add_theme_stylebox_override("panel", sb)
	parent.add_child(p)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 7)
	p.add_child(row)
	_icon(row, icon_key, 21, color)
	return _label(row, text, 18, color)

func _panel() -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.075, 0.105, 0.155, 0.96)
	sb.border_color = Color(0.43, 0.54, 0.67, 0.9)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(11)
	sb.set_content_margin_all(14)
	sb.shadow_color = Color(0.015, 0.025, 0.04, 0.45)
	sb.shadow_size = 6
	sb.shadow_offset = Vector2i(0, 3)
	p.add_theme_stylebox_override("panel", sb)
	return p


func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var top := HBoxContainer.new()
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.position = Vector2(14, 10)
	top.offset_left = 0
	top.offset_top = 0
	top.offset_right = -14
	top.offset_bottom = 48
	top.add_theme_constant_override("separation", 9)
	ui.add_child(top)
	hud_wave = _hud_chip(top, "", Color(0.80, 0.88, 0.97), "speed")
	hud_coins = _hud_chip(top, "", Color(0.91, 0.82, 0.65), "coins")
	hud_hp = _hud_chip(top, "", Color(0.83, 0.88, 0.92), "tower")
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(spacer)
	var btn_sound := _button(top, "ВКЛ", 14)
	btn_sound.custom_minimum_size = Vector2(82, 40)
	_apply_button_icon(btn_sound, "sound", 20)
	btn_sound.pressed.connect(func():
		sound_on = not sound_on
		btn_sound.text = "ВКЛ" if sound_on else "ВЫКЛ"
		btn_sound.modulate = Color.WHITE if sound_on else Color(0.66, 0.70, 0.77)
		_apply_audio_mute()
		_save(true))
	var btn_speed := _button(top, "1×", 16)
	btn_speed.custom_minimum_size = Vector2(64, 40)
	_apply_button_icon(btn_speed, "speed", 20)
	btn_speed.pressed.connect(func():
		speed_x2 = not speed_x2
		Engine.time_scale = 2.0 if speed_x2 else 1.0
		btn_speed.text = "2×" if speed_x2 else "1×")
	var btn_pause := _button(top, "", 20)
	btn_pause.custom_minimum_size = Vector2(44, 40)
	_apply_button_icon(btn_pause, "pause", 20)
	btn_pause.pressed.connect(func():
		paused = not paused
		_apply_audio_mute()
		if paused:
			_notify_yandex_gameplay_stop()
		elif state in ["prep", "battle", "choice"] and not platform_paused:
			_notify_yandex_gameplay_start()
		btn_pause.icon = ui_icons["play"] if paused else ui_icons["pause"])
	hud_hint_panel = PanelContainer.new()
	hud_hint_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hud_hint_panel.position = Vector2(-300, 48)
	hud_hint_panel.custom_minimum_size = Vector2(600, 42)
	var hint_style := StyleBoxFlat.new()
	hint_style.bg_color = Color(0.055, 0.075, 0.11, 0.96)
	hint_style.border_color = Color(0.42, 0.52, 0.65, 0.92)
	hint_style.set_border_width_all(1)
	hint_style.set_corner_radius_all(9)
	hint_style.content_margin_left = 12
	hint_style.content_margin_right = 12
	hint_style.content_margin_top = 5
	hint_style.content_margin_bottom = 5
	hud_hint_panel.add_theme_stylebox_override("panel", hint_style)
	ui.add_child(hud_hint_panel)
	hud_hint = _label(hud_hint_panel, "", 17, Color(0.89, 0.92, 0.96))
	hud_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var ab := HBoxContainer.new()
	ab.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	ab.position = Vector2(230, -84)
	ab.add_theme_constant_override("separation", 12)
	ui.add_child(ab)
	for id in ["bucket", "chord", "cat"]:
		var names := {"bucket": "ВЕДРО  ·  ВОДА", "chord": "АККОРД", "cat": "КОТИК"}
		var b := _button(ab, names[id], 18)
		b.custom_minimum_size = Vector2(190, 56)
		_apply_button_icon(b, {"bucket": "bucket", "chord": "music", "cat": "cat"}[id], 30)
		b.pressed.connect(_use_ability.bind(id))
		ability_btns[id] = b
	for i in Data.PADS.size():
		var pos: Vector2 = Data.PADS[i]
		var b := _button(ui, "＋", 22)
		b.position = pos + Vector2(-21, -64)
		b.custom_minimum_size = Vector2(42, 42)
		b.pressed.connect(_on_slot_clicked.bind(i))
		slot_btns.append(b)
		var up := _button(ui, "↑ +", 15)
		up.custom_minimum_size = Vector2(76, 38)
		up.add_theme_color_override("font_color", Color(0.16, 0.12, 0.04))
		up.add_theme_color_override("font_hover_color", Color(0.10, 0.08, 0.02))
		up.add_theme_color_override("font_pressed_color", Color(0.24, 0.10, 0.02))
		up.add_theme_color_override("font_disabled_color", Color(0.48, 0.43, 0.30))
		up.add_theme_stylebox_override("normal", _upgrade_button_style(Color(1.0, 0.77, 0.20), Color(1.0, 0.94, 0.52), true))
		up.add_theme_stylebox_override("hover", _upgrade_button_style(Color(1.0, 0.90, 0.32), Color(1.0, 0.99, 0.72), true))
		up.add_theme_stylebox_override("pressed", _upgrade_button_style(Color(0.98, 0.58, 0.16), Color(1.0, 0.82, 0.42), false))
		_apply_button_icon(up, "upgrade", 17)
		up.tooltip_text = "Улучшить башню"
		up.visible = false
		up.pressed.connect(_on_tower_upgrade_pressed.bind(i))
		tower_upgrade_btns.append(up)
	_build_portrait()
	_build_shop()
	_build_choice()
	_build_menu()
	_build_hub()
	_build_over()
	_build_slot_popup()

func _build_portrait() -> void:
	portrait_box = Control.new()
	portrait_box.position = Vector2(8, 210)
	portrait_box.size = Vector2(250, 500)
	portrait_box.pivot_offset = Vector2(125, 500)
	ui.add_child(portrait_box)
	portrait_img = TextureRect.new()
	portrait_img.texture = tex["portrait"]
	portrait_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	portrait_img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	portrait_img.set_anchors_preset(Control.PRESET_FULL_RECT)
	portrait_box.add_child(portrait_img)
	bubble_panel = _panel()
	bubble_panel.position = Vector2(8, 108)
	bubble_panel.custom_minimum_size = Vector2(260, 0)
	ui.add_child(bubble_panel)
	bubble_label = _label(bubble_panel, "", 18)
	bubble_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bubble_panel.visible = false
	portrait_box.visible = false


func say(text: String, mood_name := "idle", dur := 2.8) -> void:
	bubble_label.text = text
	mood = mood_name
	mood_t = dur
	say_t = dur
	bubble_panel.visible = portrait_box.visible


func _sync_portrait() -> void:
	portrait_box.visible = state in ["menu", "prep", "choice", "over"]
	if not portrait_box.visible:
		bubble_panel.visible = false
	_refresh_tower_controls()
	for ability_id in ability_btns:
		ability_btns[ability_id].visible = state == "battle"


func _animate_portrait(delta: float) -> void:
	if not portrait_box.visible:
		return
	if mood_t > 0.0:
		mood_t = maxf(0.0, mood_t - delta)
	elif mood != "idle":
		mood = "idle"
	if say_t > 0.0:
		say_t -= delta
		if say_t <= 0.0:
			bubble_panel.visible = false
	# Animate the large portrait only on the post-wave upgrade choice screen.
	# It eases into view, then breathes and gently sways; the tiny map avatar stays untouched.
	if state == "choice":
		portrait_anim_t += delta
		choice_portrait_intro = minf(1.0, choice_portrait_intro + delta * 3.4)
		var enter := 1.0 - pow(1.0 - choice_portrait_intro, 3.0)
		var breath := sin(portrait_anim_t * 2.2)
		portrait_box.position = Vector2(8.0, 210.0 + 10.0 * (1.0 - enter) + sin(portrait_anim_t * 1.4) * 1.5)
		var size_pulse := lerpf(0.94, 1.0, enter) * (1.0 + 0.009 * breath)
		portrait_box.scale = Vector2.ONE * size_pulse
		portrait_box.rotation = deg_to_rad(0.45 * sin(portrait_anim_t * 1.1))
	else:
		portrait_box.position = Vector2(8.0, 210.0)
		portrait_box.scale = Vector2.ONE
		portrait_box.rotation = 0.0


func _build_shop() -> void:
	shop_panel = _panel()
	shop_panel.position = Vector2(290, 92)
	shop_panel.custom_minimum_size = Vector2(760, 0)
	ui.add_child(shop_panel)
	_refresh_shop()


func _request_rewarded_ad() -> void:
	if rewarded_ad_used or rewarded_ad_pending:
		return
	if not OS.has_feature("web"):
		hud_hint.text = "Бонусное видео доступно в версии на Яндекс Играх."
		return
	var available = JavaScriptBridge.eval("Boolean(window.ysdk && window.ysdk.adv)")
	if not available:
		hud_hint.text = "Видео пока недоступно. Попробуй позже."
		return
	rewarded_ad_pending = true
	rewarded_ad_claimed = false
	ad_pause_active = true
	_apply_audio_mute()
	_notify_yandex_gameplay_stop()
	var started = JavaScriptBridge.eval("window.yandexShowRewardedAd && window.yandexShowRewardedAd()")
	if not started:
		rewarded_ad_pending = false
		ad_pause_active = false
		_apply_audio_mute()
		hud_hint.text = "Видео пока недоступно. Попробуй позже."
		if state in ["prep", "battle", "choice"] and not paused and not platform_paused:
			_notify_yandex_gameplay_start()


func _refresh_shop() -> void:
	for c in shop_panel.get_children():
		c.queue_free()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 9)
	shop_panel.add_child(vb)
	var title := HBoxContainer.new()
	title.add_theme_constant_override("separation", 10)
	vb.add_child(title)
	_icon(title, "shop", 28)
	_label(title, "ПОДГОТОВКА  /  ВОЛНА %d" % (wave + 1), 25, Color(0.82, 0.89, 0.97))
	var summary := HBoxContainer.new()
	summary.add_theme_constant_override("separation", 8)
	vb.add_child(summary)
	_icon(summary, "coins", 19, Color(0.91, 0.82, 0.65))
	_label(summary, "КАЗНА %d" % coins, 17, Color(0.91, 0.82, 0.65))
	_icon(summary, "tower", 19, Color(0.82, 0.88, 0.94))
	_label(summary, "ПОДЪЕЗД %d/%d" % [int(tower_hp), int(tower_max_hp)], 17, Color(0.82, 0.88, 0.94))
	_label(summary, "+5%% остатка после волны", 16, Color(0.68, 0.76, 0.86))
	var items := [
		["dmg", "Тапки потяжелее", "+5 к урону", 40, "attack"],
		["rate", "Тренировка рук", "+15% к скорострельности", 50, "speed"],
		["hp", "Укрепить подъезд", "+25 к прочности и ремонт", 45, "tower"],
		["repair", "Подлатать подъезд", "Ремонт 40 прочности", 30, "repair"],
		["ability", "Усилитель", "+30% к урону способностей", 60, "bucket"],
		["cdr", "Энергетики", "Способности на 10% быстрее", 55, "upgrade"],
	]
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 7)
	vb.add_child(grid)
	for it in items:
		var id: String = it[0]
		var lvl: int = shop_levels.get(id, 0)
		var cost := int(it[3] * pow(1.6, lvl)) if id != "repair" else int(it[3])
		var card := PanelContainer.new()
		var card_style := StyleBoxFlat.new()
		card_style.bg_color = Color(0.105, 0.15, 0.22, 0.94)
		card_style.border_color = Color(0.29, 0.39, 0.52, 0.75)
		card_style.set_border_width_all(1)
		card_style.set_corner_radius_all(8)
		card_style.set_content_margin_all(8)
		card.add_theme_stylebox_override("panel", card_style)
		card.custom_minimum_size = Vector2(360, 58)
		grid.add_child(card)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 9)
		card.add_child(row)
		_icon(row, str(it[4]), 30)
		var text_col := VBoxContainer.new()
		text_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		text_col.add_theme_constant_override("separation", 1)
		row.add_child(text_col)
		_label(text_col, "%s  ·  УР. %d" % [it[1], lvl], 16, Color(0.88, 0.92, 0.97))
		_label(text_col, it[2], 13, Color(0.65, 0.73, 0.83))
		var b := _button(row, "%d" % cost, 16)
		_apply_button_icon(b, "coins", 18)
		b.disabled = coins < cost
		b.pressed.connect(_buy.bind(id, cost))
	var barrier_head := HBoxContainer.new()
	barrier_head.add_theme_constant_override("separation", 7)
	vb.add_child(barrier_head)
	_icon(barrier_head, "repair", 20)
	_label(barrier_head, "ДИВАН-БАРРИКАДА · ПОЛНОСТЬЮ ПЕРЕКРЫВАЕТ ДОРОГУ", 16, Color(0.82, 0.89, 0.97))
	var barrier_row := HBoxContainer.new()
	barrier_row.add_theme_constant_override("separation", 8)
	vb.add_child(barrier_row)
	for bi in Data.BARRIER_POINTS.size():
		var place_name := "ЗАПАДНЫЙ ПРОЕЗД" if bi == 0 else "ФИНАЛЬНЫЙ ПРОХОД"
		var placed: bool = float(barrier_hp[bi]) > 0.0
		var barrier_btn := _button(barrier_row, ("%s · ГОТОВ" % place_name) if placed else ("ДИВАН · %d · 65 HP" % Data.BARRIER_COST), 14)
		barrier_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_apply_button_icon(barrier_btn, "repair" if placed else "coins", 18)
		barrier_btn.tooltip_text = place_name + " · перекрывает проход · прочность " + str(int(Data.BARRIER_MAX_HP[bi]))
		barrier_btn.disabled = placed or coins < Data.BARRIER_COST
		barrier_btn.pressed.connect(_buy_barrier.bind(bi))
	var outfit_head := HBoxContainer.new()
	outfit_head.add_theme_constant_override("separation", 8)
	vb.add_child(outfit_head)
	_icon(outfit_head, "outfit", 21)
	_label(outfit_head, "ОБРАЗЫ АЛЬТУШКИ", 18, Color(0.82, 0.89, 0.97))
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 7)
	vb.add_child(row2)
	for o in Data.OUTFITS:
		var owned: bool = outfits_owned.has(o["id"])
		var eq: bool = outfit_equipped == o["id"]
		var txt: String = str(o["name"])
		if eq:
			txt += " · НАДЕТО"
		elif owned:
			txt += " · ВЫБРАТЬ"
		else:
			txt += " · %d" % int(o["cost"])
		var b := _button(row2, txt, 14)
		_apply_button_icon(b, "outfit", 17)
		b.tooltip_text = o["desc"]
		b.disabled = (not owned and coins < int(o["cost"])) or eq
		b.pressed.connect(_on_outfit.bind(o["id"]))
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	vb.add_child(actions)
	var go := _button(actions, "В БОЙ  /  ВОЛНА %d" % (wave + 1), 21)
	go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_apply_button_icon(go, "attack", 23)
	go.pressed.connect(_start_wave)
	var early := _button(actions, "РАННИЙ ВЫЗОВ  ·  +5%%", 16)
	_apply_button_icon(early, "speed", 19)
	early.pressed.connect(_start_wave.bind(true))
	var ad_reward := _button(actions, "ВИДЕО · +40", 14)
	ad_reward.tooltip_text = "Посмотри рекламное видео и получи 40 монет. Один раз за забег."
	ad_reward.custom_minimum_size = Vector2(155, 48)
	_apply_button_icon(ad_reward, "coins", 18)
	ad_reward.disabled = rewarded_ad_used
	ad_reward.pressed.connect(_request_rewarded_ad)

func _buy(id: String, cost: int) -> void:
	if coins < cost:
		return
	coins -= cost
	play_sfx("coin")
	match id:
		"dmg":
			dmg += 5.0
			shop_levels["dmg"] += 1
		"rate":
			fire_rate *= 1.15
			shop_levels["rate"] += 1
		"hp":
			tower_max_hp += 25.0
			tower_hp = tower_max_hp
			shop_levels["hp"] += 1
		"repair":
			tower_hp = minf(tower_max_hp, tower_hp + 40.0)
		"ability":
			ability_mult *= 1.3
			shop_levels["ability"] += 1
		"cdr":
			cdr_mult *= 0.9
			shop_levels["cdr"] += 1
	_update_hud()
	_refresh_shop()
	_save(true)


func _on_outfit(id: String) -> void:
	for o in Data.OUTFITS:
		if o["id"] == id:
			if outfits_owned.has(id):
				outfit_equipped = id
			elif coins >= int(o["cost"]):
				coins -= int(o["cost"])
				outfits_owned.append(id)
				outfit_equipped = id
				play_sfx("coin")
	_apply_outfit_visual()
	say("Как тебе мой новый лук?", "proud", 2.6)
	_save(true)
	_update_hud()
	_refresh_shop()


func _apply_outfit_visual() -> void:
	for o in Data.OUTFITS:
		if o["id"] == outfit_equipped:
			hero.modulate = o["tint"] * Color(1.16, 1.13, 1.24)


func _outfit_bonus(key: String) -> float:
	for o in Data.OUTFITS:
		if o["id"] == outfit_equipped:
			return float(o["bonus"].get(key, 0.0))
	return 0.0


func _build_choice() -> void:
	choice_panel = _panel()
	choice_panel.position = Vector2(290, 180)
	choice_panel.custom_minimum_size = Vector2(700, 0)
	choice_panel.visible = false
	ui.add_child(choice_panel)


func _show_choice() -> void:
	state = "choice"
	shop_panel.visible = false
	choice_portrait_intro = 0.0
	portrait_anim_t = 0.0
	_sync_portrait()
	for c in choice_panel.get_children():
		c.queue_free()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	choice_panel.add_child(vb)
	_label(vb, "ВОЛНА %d ОТБИТА  /  ВЫБЕРИ УСИЛЕНИЕ" % wave, 25, Color(0.82, 0.89, 0.97))
	var pool := Data.BUFFS.duplicate()
	pool.shuffle()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	var buff_icon := {"dmg": "attack", "rate": "speed", "coins": "coins", "hp": "tower", "ability": "bucket", "cdr": "upgrade", "heal": "repair"}
	for i in 3:
		var bf: Dictionary = pool[i]
		var b := _button(row, "%s\n%s" % [bf["name"], bf["desc"]], 16)
		_apply_button_icon(b, buff_icon.get(str(bf["id"]), "tower"), 25)
		b.custom_minimum_size = Vector2(215, 110)
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.pressed.connect(_apply_buff.bind(bf["id"]))
	choice_panel.visible = true

func _apply_buff(id: String) -> void:
	play_sfx("click")
	match id:
		"dmg":
			dmg *= 1.12
		"rate":
			fire_rate *= 1.10
		"coins":
			run_coin_mult *= 1.2
		"hp":
			tower_max_hp += 20.0
			tower_hp = minf(tower_max_hp, tower_hp + 20.0)
		"ability":
			ability_mult *= 1.25
		"cdr":
			cdr_mult *= 0.85
		"heal":
			tower_hp = minf(tower_max_hp, tower_hp + 35.0)
	choice_panel.visible = false
	state = "prep"
	_sync_portrait()
	_update_hud()
	_refresh_shop()
	shop_panel.visible = true
	hud_hint.text = "Волна %d впереди. Закупитесь — и в бой!" % (wave + 1)
	_save(true)


func _build_menu() -> void:
	if is_instance_valid(menu_panel):
		menu_panel.queue_free()
	menu_panel = _panel()
	menu_panel.position = Vector2(330, 120)
	menu_panel.custom_minimum_size = Vector2(620, 0)
	ui.add_child(menu_panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	menu_panel.add_child(vb)
	var t := _label(vb, "АЛЬТУШКА:\nОБОРОНА БАШНИ", 44, Color(0.79, 0.88, 0.97))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var s := _label(vb, "Скуфы идут по двору к твоему подъезду!\nСтрой башенки на пятачках, кидай тапки с крыши,\nне дай им выломать дверь.", 19)
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var meta := _label(vb, "РЕКОРД  %d ВОЛН  ·  ЗВЁЗДЫ  %d" % [best_wave, stars], 17, Color(0.82, 0.76, 0.65))
	meta.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var hub_button := _button(vb, "ДВОР · СОСЕДИ И ПОСТРОЙКИ", 18)
	_apply_button_icon(hub_button, "shop", 22)
	hub_button.pressed.connect(_show_hub)
	if not pending_run_save.is_empty():
		var resume := _button(vb, "ПРОДОЛЖИТЬ ЗАБЕГ · ВОЛНА %d" % int(pending_run_save.get("resume_wave", 1)), 22)
		_apply_button_icon(resume, "play", 23)
		resume.pressed.connect(_resume_run)
	var b := _button(vb, "НАЧАТЬ НОВЫЙ ЗАБЕГ", 26)
	_apply_button_icon(b, "play", 25)
	b.pressed.connect(_start_run)
	var credits := _label(vb, "Иконки Game-icons.net · CC BY 3.0, кроме собственной иконки монет", 10, Color(0.48, 0.57, 0.68))
	credits.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _buy_perk(key: String, price: int) -> void:
	if stars < price or int(permanent_perks[key]) >= 5: return
	stars -= price
	permanent_perks[key] = int(permanent_perks[key]) + 1
	_save(true)
	if is_instance_valid(hub_panel) and hub_panel.visible:
		_refresh_hub()
	else:
		_build_menu()


func _build_hub() -> void:
	hub_panel = _panel()
	hub_panel.position = Vector2(290, 76)
	hub_panel.custom_minimum_size = Vector2(760, 0)
	hub_panel.visible = false
	ui.add_child(hub_panel)
	_refresh_hub()


func _refresh_hub() -> void:
	if not is_instance_valid(hub_panel):
		return
	for child in hub_panel.get_children():
		child.free()
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	hub_panel.add_child(root)
	var title := _label(root, "ДВОР · ДЕЛА СОСЕДСКИЕ", 27, Color(0.92, 0.85, 0.67))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var intro := _label(root, "Назначь соседям работу. Бонусы действуют в каждом новом забеге. Звёзды: %d" % stars, 15, Color(0.78, 0.84, 0.9))
	intro.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var residents := HBoxContainer.new()
	residents.add_theme_constant_override("separation", 8)
	root.add_child(residents)
	var resident_specs := [
		{"name": "Бабушка Нина", "texture": "td_granny"},
		{"name": "Соседка Аня", "texture": "td_girlfriend"},
		{"name": "Дворовый кот", "texture": "cat"},
	]
	var job_ids := ["income", "repair", "guard"]
	var job_names := ["Киоск · +15 монет", "Ремонт · +10 HP/волна", "Дозор · +15 HP бойцу"]
	for i in resident_specs.size():
		var card := _panel()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		residents.add_child(card)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 4)
		card.add_child(cv)
		var face := TextureRect.new()
		face.texture = tex[resident_specs[i]["texture"]]
		face.custom_minimum_size = Vector2(72, 86)
		face.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		face.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		face.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cv.add_child(face)
		var name_label := _label(cv, resident_specs[i]["name"], 15, Color(0.94, 0.91, 0.82))
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var job := OptionButton.new()
		job.custom_minimum_size = Vector2(190, 34)
		job.add_theme_font_size_override("font_size", 13)
		for j in job_names.size(): job.add_item(job_names[j])
		job.select(maxi(0, job_ids.find(resident_jobs[i])))
		job.item_selected.connect(_set_resident_job.bind(i))
		cv.add_child(job)
	var divider := HSeparator.new()
	root.add_child(divider)
	var building_row := HBoxContainer.new()
	building_row.add_theme_constant_override("separation", 8)
	root.add_child(building_row)
	var buildings := [
		{"id":"damage", "name":"МАСТЕРСКАЯ", "effect":"+8% урона", "icon":"attack"},
		{"id":"income", "name":"КИОСК", "effect":"+10 старт · +5% добыча", "icon":"coins"},
		{"id":"hp", "name":"ЛАЗАРЕТ", "effect":"+15 HP подъезда", "icon":"repair"},
	]
	for data in buildings:
		var card := _panel()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		building_row.add_child(card)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 4)
		card.add_child(cv)
		var head := HBoxContainer.new()
		_icon(head, data["icon"], 23, Color(0.94, 0.78, 0.46))
		var building_name := _label(head, data["name"], 15, Color(0.94, 0.85, 0.66))
		building_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cv.add_child(head)
		_label(cv, "%s · ур. %d/5" % [data["effect"], int(permanent_perks[data["id"]])], 13)
		var price := 3 + int(permanent_perks[data["id"]]) * 3
		var upgrade := _button(cv, "УЛУЧШИТЬ · %d ★" % price, 14)
		upgrade.disabled = stars < price or int(permanent_perks[data["id"]]) >= 5
		upgrade.pressed.connect(_buy_perk.bind(data["id"], price))
	var back := _button(root, "НАЗАД В МЕНЮ", 16)
	back.pressed.connect(_close_hub)


func _set_resident_job(job_index: int, resident_index: int) -> void:
	var ids := ["income", "repair", "guard"]
	if resident_index < 0 or resident_index >= resident_jobs.size() or job_index < 0 or job_index >= ids.size():
		return
	resident_jobs[resident_index] = ids[job_index]
	_save(true)
	_refresh_hub()


func _show_hub() -> void:
	if state != "menu": return
	menu_panel.visible = false
	hub_panel.visible = true
	_refresh_hub()


func _close_hub() -> void:
	hub_panel.visible = false
	_build_menu()
	menu_panel.visible = true


func _build_over() -> void:
	over_panel = _panel()
	over_panel.position = Vector2(330, 180)
	over_panel.custom_minimum_size = Vector2(620, 0)
	over_panel.visible = false
	ui.add_child(over_panel)


func _build_slot_popup() -> void:
	slot_popup = _panel()
	slot_popup.custom_minimum_size = Vector2(320, 0)
	slot_popup.visible = false
	ui.add_child(slot_popup)


func _refresh_tower_controls() -> void:
	var controls_visible := state in ["prep", "battle"]
	for i in slot_btns.size():
		var slot_button: Button = slot_btns[i]
		var upgrade_button: Button = tower_upgrade_btns[i]
		var pos: Vector2 = Data.PADS[i]
		slot_button.visible = controls_visible
		if towers[i] == null:
			slot_button.text = "＋"
			slot_button.custom_minimum_size = Vector2(42, 42)
			slot_button.position = pos + Vector2(-21, -64)
			upgrade_button.visible = false
			continue
		slot_button.text = "⚙"
		slot_button.custom_minimum_size = Vector2(34, 34)
		slot_button.position = pos + Vector2(27, -45)
		var tower: Dictionary = towers[i]
		var level := int(tower["level"])
		var needs_branch := level == 3 and str(tower.get("branch", "")).is_empty()
		var cost := 50 * level
		var can_upgrade := level < 4 and coins >= cost
		upgrade_button.visible = controls_visible and (needs_branch or can_upgrade)
		if not upgrade_button.visible:
			continue
		if needs_branch:
			upgrade_button.text = "★ ВЫБРАТЬ"
			upgrade_button.tooltip_text = "Выбрать специализацию башни"
		else:
			upgrade_button.text = "↑ %d" % cost
			upgrade_button.tooltip_text = "Улучшить до уровня %d за %d монет" % [level + 1, cost]
		var sprite: Sprite2D = tower["node"].get_child(0)
		var tower_height := 72.0
		if sprite.texture:
			tower_height = float(sprite.texture.get_height()) * absf(sprite.scale.y)
		upgrade_button.position = Vector2(clampf(pos.x - 38.0, 2.0, 1202.0), clampf(pos.y - tower_height - 43.0, 54.0, 678.0))


func _on_tower_upgrade_pressed(i: int) -> void:
	if i < 0 or i >= towers.size() or towers[i] == null:
		return
	var tower: Dictionary = towers[i]
	var level := int(tower["level"])
	if level == 3 and str(tower.get("branch", "")).is_empty():
		_on_slot_clicked(i)
		return
	var cost := 50 * level
	if level < 4 and coins >= cost:
		_upgrade_tower(i, cost)


func _queue_slot_popup_refresh() -> void:
	if slot_popup_refresh_queued or not is_instance_valid(slot_popup) or not slot_popup.visible or slot_popup_slot < 0:
		return
	slot_popup_refresh_queued = true
	call_deferred("_refresh_open_slot_popup")


func _refresh_open_slot_popup() -> void:
	slot_popup_refresh_queued = false
	if is_instance_valid(slot_popup) and slot_popup.visible and state in ["prep", "battle"] and slot_popup_slot >= 0:
		_on_slot_clicked(slot_popup_slot)


func _tower_scale(type_id: String, level: int) -> Vector2:
	var base := 1.0 + 0.12 * float(level - 1)
	var height_bonus := 1.10 if type_id in ["girlfriend", "granny", "cat", "patrol"] else 1.0
	return Vector2(base, base * height_bonus)


func _tower_tex_name(type_id: String) -> String:
	return {"girlfriend": "td_girlfriend", "speaker": "speaker", "granny": "td_granny", "cat": "td_cat", "kiosk": "speaker", "patrol": "td_granny"}[type_id]


func _on_slot_clicked(i: int) -> void:
	if state not in ["prep", "battle"]:
		return
	slot_popup_slot = i
	for c in slot_popup.get_children():
		c.queue_free()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	slot_popup.add_child(vb)
	var t = towers[i]
	if t == null:
		_label(vb, "ПОСТРОИТЬ БАШНЮ", 18)
		var tower_icons := {"girlfriend": "attack", "speaker": "music", "granny": "repair", "cat": "cat", "kiosk": "coins", "patrol": "tower"}
		for type_id in Data.TOWER_TYPES:
			var info: Dictionary = Data.TOWER_TYPES[type_id]
			var b := _button(vb, "%s  ·  %d\n%s" % [info["name"], int(info["cost"]), info["desc"]], 16)
			_apply_button_icon(b, tower_icons.get(type_id, "tower"), 25)
			b.disabled = coins < int(info["cost"])
			b.pressed.connect(_build_tower.bind(i, type_id))
	else:
		_label(vb, "%s (ур. %d)" % [Data.TOWER_TYPES[t["type"]]["name"], t["level"]], 20)
		_label(vb, "Радиус: %d" % int(Data.TOWER_TYPES[t["type"]]["range"]), 16)
		if int(t["level"]) == 3 and not branch_choices.has(str(i)):
			_label(vb, "Выбери специализацию:", 16)
			for path in ["power", "control"]:
				var branch_name := "Тяжёлый залп" if path == "power" else "Контроль толпы"
				if t["type"] == "speaker": branch_name = "Бас-удар" if path == "power" else "Глубокий бас"
				elif t["type"] == "patrol": branch_name = "Крепкий сосед" if path == "power" else "Холодный свисток"
				elif t["type"] == "kiosk": branch_name = "Больше сдачи" if path == "power" else "Быстрый оборот"
				var bb := _button(vb, branch_name, 15)
				_apply_button_icon(bb, "upgrade" if path == "power" else "tower", 18)
				bb.pressed.connect(_choose_branch.bind(i, path))
		elif int(t["level"]) < 4:
			var cost := 50 * int(t["level"])
			var b := _button(vb, "УЛУЧШИТЬ  ·  %d  (+40%%)" % cost, 16)
			_apply_button_icon(b, "upgrade", 18)
			b.disabled = coins < cost
			b.pressed.connect(_upgrade_tower.bind(i, cost))
		else:
			_label(vb, "Макс. уровень · %s" % str(branch_choices.get(str(i), "")), 16)
		var sell := _button(vb, "ПРОДАТЬ  ·  +%d" % _sell_value(t), 16)
		_apply_button_icon(sell, "coins", 18)
		sell.pressed.connect(_sell_tower.bind(i))
	var cancel := _button(vb, "Закрыть", 16)
	cancel.pressed.connect(func():
		slot_popup.visible = false
		slot_popup_slot = -1
		queue_redraw())
	var pos: Vector2 = Data.PADS[i]
	slot_popup.position = Vector2(clampf(pos.x - 160, 8, 950), clampf(pos.y - 250, 60, 380))
	slot_popup.visible = true
	queue_redraw()

func _choose_branch(i: int, path: String) -> void:
	branch_choices[str(i)] = path
	if towers[i] != null:
		towers[i]["branch"] = path
		slot_popup.visible = false
		_update_hud()
		queue_redraw()
		_save(true)


func _sell_value(t: Dictionary) -> int:
	var base := int(Data.TOWER_TYPES[t["type"]]["cost"])
	return int((base + 50 * (int(t["level"]) - 1)) * 0.6)


func _build_tower(i: int, type_id: String) -> void:
	var info: Dictionary = Data.TOWER_TYPES[type_id]
	if coins < int(info["cost"]) or towers[i] != null:
		return
	coins -= int(info["cost"])
	play_sfx("coin")
	var node := Node2D.new()
	node.position = Data.PADS[i]
	node.z_index = 90 + int(node.position.y)
	var tex_name := _tower_tex_name(type_id)
	var spr := Sprite2D.new()
	spr.texture = tex[tex_name]
	spr.offset = Vector2(0, -tex[tex_name].get_height() / 2.0)
	spr.scale = _tower_scale(type_id, 1)
	node.add_child(spr)
	add_child(node)
	towers[i] = {"type": type_id, "level": 1, "node": node, "timer": 0.0, "branch": ""}
	slot_btns[i].text = "⚙"
	slot_popup.visible = false
	slot_popup_slot = -1
	_update_hud()
	queue_redraw()
	_save(true)


func _buy_barrier(index: int) -> void:
	if index < 0 or index >= barrier_hp.size() or barrier_hp[index] > 0.0 or coins < Data.BARRIER_COST:
		return
	coins -= Data.BARRIER_COST
	barrier_hp[index] = Data.BARRIER_MAX_HP[index]
	if index < barrier_sprites.size():
		barrier_sprites[index].visible = true
	play_sfx("coin")
	_update_hud()
	_refresh_shop()
	queue_redraw()
	_save(true)


func _upgrade_tower(i: int, cost: int) -> void:
	if coins < cost:
		return
	coins -= cost
	play_sfx("coin")
	towers[i]["level"] = int(towers[i]["level"]) + 1
	var spr: Sprite2D = towers[i]["node"].get_child(0)
	spr.scale = _tower_scale(str(towers[i]["type"]), int(towers[i]["level"]))
	slot_popup.visible = false
	slot_popup_slot = -1
	_update_hud()
	queue_redraw()
	_save(true)


func _sell_tower(i: int) -> void:
	var refund := _sell_value(towers[i])
	coins += refund
	if state == "battle":
		coins_earned_wave += refund
	play_sfx("coin")
	towers[i]["node"].queue_free()
	towers[i] = null
	slot_btns[i].text = "＋"
	slot_popup.visible = false
	slot_popup_slot = -1
	_update_hud()
	queue_redraw()
	_save(true)



func _show_menu() -> void:
	_notify_yandex_gameplay_stop()
	state = "menu"
	_sync_portrait()
	say("Скуфы опять прут во двор... Тапки начищены?", "idle", 4.0)
	menu_panel.visible = true
	if is_instance_valid(hub_panel): hub_panel.visible = false
	shop_panel.visible = false
	hud_hint.text = ""


func _resume_run() -> void:
	if pending_run_save.is_empty():
		return
	var saved: Dictionary = pending_run_save.duplicate(true)
	pending_run_save.clear()
	menu_panel.visible = false
	over_panel.visible = false
	var phase := str(saved.get("phase", "prep"))
	wave = int(saved.get("resume_wave", 1))
	if phase == "battle":
		wave = maxi(0, wave - 1)
	coins = int(saved.get("coins", 80))
	coins_earned_wave = int(saved.get("coins_earned_wave", 0))
	if phase == "battle":
		# Combat resumes from the start of the saved wave, so replayed enemies must not duplicate their rewards.
		coins = maxi(0, coins - coins_earned_wave)
	coins_earned_wave = 0
	run_level = int(saved.get("run_level", 1))
	kills = int(saved.get("kills", 0))
	tower_hp = float(saved.get("tower_hp", 100.0))
	tower_max_hp = float(saved.get("tower_max_hp", 100.0))
	dmg = float(saved.get("dmg", 10.0))
	fire_rate = float(saved.get("fire_rate", 2.0))
	ability_mult = float(saved.get("ability_mult", 1.0))
	cdr_mult = float(saved.get("cdr_mult", 1.0))
	run_coin_mult = float(saved.get("run_coin_mult", 1.0))
	guard_hp_bonus = float(saved.get("guard_hp_bonus", 0.0))
	shop_levels = saved.get("shop_levels", {"dmg": 0, "rate": 0, "hp": 0, "ability": 0, "cdr": 0})
	branch_choices = saved.get("branch_choices", {})
	barrier_hp = saved.get("barrier_hp", [0.0, 0.0])
	rewarded_ad_used = bool(saved.get("rewarded_ad_used", false))
	var saved_towers: Array = saved.get("towers", [])
	for i in towers.size():
		if towers[i] != null and is_instance_valid(towers[i]["node"]):
			towers[i]["node"].queue_free()
		towers[i] = null
		if i >= saved_towers.size() or saved_towers[i].is_empty():
			slot_btns[i].text = "＋"
			continue
		var tower_data: Dictionary = saved_towers[i]
		var type_id := str(tower_data.get("type", ""))
		if not Data.TOWER_TYPES.has(type_id):
			continue
		var saved_coins := coins
		coins = int(Data.TOWER_TYPES[type_id]["cost"])
		_build_tower(i, type_id)
		coins = saved_coins
		if towers[i] != null:
			towers[i]["level"] = clampi(int(tower_data.get("level", 1)), 1, 4)
			towers[i]["branch"] = str(tower_data.get("branch", ""))
			var saved_branch := str(towers[i]["branch"])
			if saved_branch != "":
				branch_choices[str(i)] = saved_branch
			var sprite: Sprite2D = towers[i]["node"].get_child(0)
			sprite.scale = _tower_scale(type_id, int(towers[i]["level"]))
			if saved_branch != "": sprite.modulate = Color(1.15, 0.84, 0.66) if saved_branch == "power" else Color(0.72, 0.88, 1.15)
	for i in barrier_sprites.size():
		barrier_sprites[i].visible = i < barrier_hp.size() and float(barrier_hp[i]) > 0.0
	state = "prep"
	paused = false
	platform_paused = false
	_apply_audio_mute()
	_sync_portrait()
	shop_panel.visible = true
	_update_hud()
	_refresh_shop()
	queue_redraw()
	_notify_yandex_gameplay_start()
	_request_platform_fullscreen()
	if phase == "choice":
		_show_choice()
	else:
		hud_hint.text = "Забег восстановлен. Волна %d впереди — закупись и продолжай!" % (wave + 1)
	_save(true)


func _start_run() -> void:
	pending_run_save.clear()
	menu_panel.visible = false
	over_panel.visible = false
	wave = 0
	bg.modulate = Color.WHITE
	coins = 80 + int(permanent_perks["income"]) * 10 + resident_jobs.count("income") * 15
	run_level = 1
	barrier_hp = [0.0, 0.0]
	for sofa in barrier_sprites:
		sofa.visible = false
	queue_redraw()
	tutorial_active = false
	tutorial_elapsed = 0.0
	rewarded_ad_used = false
	coins_earned_wave = 0
	first_wave_protection = false
	branch_choices.clear()
	run_coin_mult = 1.0
	tower_max_hp = 100.0 + 15.0 * permanent_perks["hp"]
	tower_hp = tower_max_hp
	guard_hp_bonus = resident_jobs.count("guard") * 15.0
	kills = 0
	dmg = 10.0 * (1.0 + 0.08 * permanent_perks["damage"])
	fire_rate = 2.0
	ability_mult = 1.0
	cdr_mult = 1.0
	shop_levels = {"dmg": 0, "rate": 0, "hp": 0, "ability": 0, "cdr": 0}
	for e in enemies:
		if is_instance_valid(e):
			e.queue_free()
	enemies.clear()
	for guard in guard_units:
		var gnode = guard.get("node")
		if is_instance_valid(gnode): gnode.queue_free()
	guard_units.clear()
	for i in towers.size():
		if towers[i] != null:
			towers[i]["node"].queue_free()
			towers[i] = null
		slot_btns[i].text = "＋"
	cooldowns = {"bucket": 0.0, "chord": 0.0, "cat": 0.0}
	cat_active = false
	cat_target = null
	if cat_node:
		cat_node.visible = false
	state = "prep"
	paused = false
	_apply_audio_mute()
	_sync_portrait()
	_notify_yandex_gameplay_start()
	_request_platform_fullscreen()
	say("Погнали! Не подпусти их к подъезду!", "idle", 3.2)
	shop_panel.visible = true
	_update_hud()
	_refresh_shop()
	hud_hint.text = "ОБУЧЕНИЕ: выбери башню на площадке с «+»; нажми «В бой», когда будешь готова. Первая волна безопасна."
	_save(true)


func _start_wave(early := false) -> void:
	early_call_bonus = 0.05 if early else 0.0
	play_sfx("click")
	shop_panel.visible = false
	slot_popup.visible = false
	slot_popup_slot = -1
	queue_redraw()
	wave += 1
	spawn_queue = Data.build_wave(wave)
	spawn_timer = 0.5
	state = "battle"
	coins_earned_wave = 0
	first_wave_protection = wave == 1
	tutorial_active = wave == 1
	tutorial_elapsed = 0.0
	_sync_portrait()
	var phrase: String = ["Волна %d! Держимся!", "Тапки к бою!", "Они сами напросились!"].pick_random()
	if phrase.contains("%d"):
		phrase = phrase % wave
	say(phrase, "idle", 2.2)
	bg.modulate = Color(0.55, 0.62, 0.9) if wave % 2 == 0 else Color.WHITE
	var wave_note := "ночь — скуфы злее" if wave % 2 == 0 else "держим все подходы"
	hud_hint.text = ("ВОЛНА 1  ·  ПОДЪЕЗД ЗАЩИЩЁН  ·  %s" % wave_note) if wave == 1 else ("ВОЛНА %d  ·  %s" % [wave, wave_note])
	_update_hud()
	_save(true)


# ---------- Игровой процесс ----------

func _process(delta: float) -> void:
	hud_hint_panel.visible = state != "menu" and not hud_hint.text.is_empty()
	if save_pending:
		save_delay -= delta
		if save_delay <= 0.0:
			_write_save()
	if paused or platform_paused or ad_pause_active:
		return
	anim_t += delta
	_animate_portrait(delta)
	for ui_button_index in tower_upgrade_btns.size():
		var upgrade_button: Button = tower_upgrade_btns[ui_button_index]
		if upgrade_button.visible:
			var pulse := 1.0 + 0.045 * sin(anim_t * 5.0 + float(ui_button_index))
			upgrade_button.scale = Vector2.ONE * pulse
		else:
			upgrade_button.scale = Vector2.ONE
	_update_cooldown_ui()
	if state != "battle":
		_update_fx(delta)
		return
	if tutorial_active and wave == 1:
		tutorial_elapsed += delta
		var tutorial_step := mini(3, int(tutorial_elapsed / 3.5))
		var tutorial_lines := [
			"ОБУЧЕНИЕ 1/4 · Альтушка автоматически кидает тапки по скуфам.",
			"ОБУЧЕНИЕ 2/4 · Нажми «+» на площадке и построй башню — это можно делать и в бою.",
			"ОБУЧЕНИЕ 3/4 · Кнопки снизу — способности. КОТИК сам летит прямо к опасному врагу.",
			"ОБУЧЕНИЕ 4/4 · За скуфов дают монеты; после победы выбери одно из трёх усилений. Первая волна безопасна."
		]
		hud_hint.text = tutorial_lines[tutorial_step]
		if tutorial_elapsed >= 14.0:
			tutorial_active = false
	if not spawn_queue.is_empty():
		spawn_timer -= delta
		if spawn_timer <= 0.0:
			spawn_timer = maxf(0.45, 1.1 - wave * 0.04)
			_spawn_enemy(spawn_queue.pop_front())
	hero_timer -= delta
	if hero_timer <= 0.0:
		var target := _pick_target_in_range(Data.HERO_POS, Data.HERO_RANGE)
		if target:
			hero_timer = 1.0 / (fire_rate * (1.0 + _outfit_bonus("rate")))
			_fire(Data.HERO_POS + Vector2(-20, -50), target, dmg * (1.0 + _outfit_bonus("dmg")), Color.WHITE)
	for ti in towers.size():
		var t = towers[ti]
		if t == null:
			continue
		var tspr: Sprite2D = t["node"].get_child(0)
		var lvl_scale := 1.0 + 0.12 * (int(t["level"]) - 1)
		if t["type"] == "speaker":
			tspr.scale = _tower_scale(str(t["type"]), int(t["level"])) * (1.0 + 0.045 * sin(anim_t * 6.0))
			tspr.rotation = 0.0
		else:
			tspr.scale = _tower_scale(str(t["type"]), int(t["level"]))
			tspr.rotation = sin(anim_t * 1.5 + float(ti) * 1.7) * 0.035
		t["timer"] = float(t["timer"]) - delta
		var info: Dictionary = Data.TOWER_TYPES[t["type"]]
		if t["type"] == "kiosk":
			if float(t["timer"]) <= 0.0:
				t["timer"] = 7.0 if str(t.get("branch", "")) == "control" else 8.0
				var payout_base := 8.0 + 2.0 * float(int(t["level"]) - 1)
				if str(t.get("branch", "")) == "power": payout_base *= 1.4
				var payout := int(round(payout_base * (1.0 + 0.05 * permanent_perks["income"])))
				coins += payout
				coins_earned_wave += payout
				_float_text(t["node"].position + Vector2(0, -60), "+%d" % payout, Color(0.6, 1.0, 0.65), 18)
				_update_hud()
				_save()
			continue
		if t["type"] == "patrol":
			if float(t["timer"]) <= 0.0:
				var mark := _pick_target_in_range(t["node"].position, float(info["range"]))
				if mark and _spawn_guard(ti, mark, t):
					t["timer"] = maxf(12.0, 19.0 - 1.5 * (int(t["level"]) - 1))
				else:
					t["timer"] = 1.0
			continue
		var mult := 1.0 + 0.4 * (int(t["level"]) - 1)
		if str(t.get("branch", "")) == "power": mult *= 1.3
		var origin: Vector2 = t["node"].position + Vector2(0, -60)
		if t["type"] == "speaker":
			if float(t["timer"]) <= 0.0:
				t["timer"] = 0.5
				var center: Vector2 = t["node"].position + Vector2(0, -20)
				var hit_any := false
				for e in enemies:
					if is_instance_valid(e) and not e.dead and e.position.distance_to(center) <= float(info["range"]):
						e.apply_slow(0.65 if str(t.get("branch", "")) != "control" else 0.48, 0.7)
						e.take_damage(float(info["dmg"]) * mult)
						hit_any = true
				if hit_any:
					fx_rings.append({"pos": center, "r": 10.0, "max": float(info["range"]), "color": Color(0.6, 0.8, 1, 0.5), "t": 0.0})
		else:
			if float(t["timer"]) <= 0.0:
				var target := _pick_target_in_range(t["node"].position, float(info["range"]))
				if target:
					t["timer"] = 1.0 / float(info["rate"])
					var tint := Color.WHITE
					if str(t.get("branch", "")) == "control": target.apply_slow(0.72, 1.1)
					if t["type"] == "girlfriend":
						tint = Color(1, 0.85, 0.9)
					elif t["type"] == "cat":
						tint = Color(1.2, 0.9, 0.6)
					_fire(origin, target, float(info["dmg"]) * mult, tint)
	_update_guards(delta)
	_update_cat(delta)
	_update_fx(delta)
	if spawn_queue.is_empty() and enemies.is_empty() and state == "battle":
		_wave_cleared()


func _spawn_enemy(kind: String) -> void:
	var stats: Dictionary = Data.ENEMIES[kind]
	var e = Enemy.new()
	add_child(e)
	var route: Array = Data.ROUTES.pick_random()
	e.setup(kind, stats, tex[stats["tex"]], self, Data.hp_scale(wave), Data.speed_scale(wave), route)
	if kind == "armored": e.sprite.modulate = Color(0.85, 0.92, 1.0)
	if kind == "regen": e.sprite.modulate = Color(0.65, 1.0, 0.75)
	enemies.append(e)
	if kind == "boss":
		hud_hint.text = "⚠️ ГЛАВНЫЙ СКУФ на диване!"
		say("Ого... Главный Скуф на диване!", "panic", 3.4)
		_float_text(Vector2(560, 200), "ГЛАВНЫЙ СКУФ!", Color(1, 0.4, 0.3), 30)


## Прицел «по первому»: враг, дальше всех прошедший по маршруту.
func _pick_target_in_range(from: Vector2, range_: float) -> Node:
	var best: Node = null
	for e in enemies:
		if is_instance_valid(e) and not e.dead and e.position.distance_to(from) <= range_:
			if best == null or e.progress > best.progress:
				best = e
	return best


func _fire(from: Vector2, target: Node, damage: float, tint: Color) -> void:
	var p = Projectile.new()
	p.z_index = 900
	add_child(p)
	p.setup(tex["tapok"], from, target, damage, self, tint)
	play_sfx("shoot")


func damage_barrier(index: int, amount: float) -> bool:
	if first_wave_protection:
		return false
	if index < 0 or index >= barrier_hp.size(): return true
	barrier_hp[index] = maxf(0.0, barrier_hp[index] - amount * 0.6)
	if index < barrier_sprites.size() and barrier_hp[index] <= 0.0:
		barrier_sprites[index].visible = false
	queue_redraw()
	_save()
	return barrier_hp[index] <= 0.0


func damage_tower(amount: float) -> void:
	if state != "battle" or first_wave_protection:
		return
	tower_hp -= amount * 0.6
	play_sfx("hurt")
	if tower_hp < 35.0 and tower_hp > 0.0 and anim_t - last_panic_say > 6.0:
		last_panic_say = anim_t
		say("Подъезд трещит! Почини его в магазине!", "panic", 3.0)
	# Damage is communicated through the HUD, not by flashing/tinting the heroine.
	_update_hud()
	_save()
	if tower_hp <= 0.0:
		tower_hp = 0.0
		_game_over()


func _current_outfit_tint() -> Color:
	for o in Data.OUTFITS:
		if o["id"] == outfit_equipped:
			return o["tint"]
	return Color.WHITE


func on_enemy_killed(e: Node) -> void:
	enemies.erase(e)
	kills += 1
	var gain := int(round(e.reward * run_coin_mult * (1.0 + _outfit_bonus("coins")) * (1.0 + 0.05 * permanent_perks["income"])))
	coins += gain
	coins_earned_wave += gain
	play_sfx("coin")
	_float_text(e.position + Vector2(0, -70), "+%d" % gain, Color(0.90, 0.80, 0.61), 20)
	_update_hud()
	_save()


func _wave_cleared() -> void:
	first_wave_protection = false
	var bonus := int(round((20 + 5 * wave) * (1.0 + early_call_bonus)))
	early_call_bonus = 0.0
	coins += bonus
	var neighbor_repair := resident_jobs.count("repair") * 10.0
	if neighbor_repair > 0.0:
		var healed := minf(neighbor_repair, tower_max_hp - tower_hp)
		if healed > 0.0:
			tower_hp += healed
			_float_text(Data.HERO_POS + Vector2(0, -85), "+%d HP · СОСЕДИ ПОЧИНИЛИ" % int(healed), Color(0.48, 1.0, 0.72), 17)
			fx_rings.append({"pos": Data.HERO_POS, "r": 18.0, "max": 88.0, "color": Color(0.45, 0.95, 0.68, 0.55), "t": 0.0})
	var earned := 1 if tower_hp < tower_max_hp * 0.35 else (2 if tower_hp < tower_max_hp * 0.75 else 3)
	stars += earned
	coins += int(floor(float(coins) * 0.05))
	run_level += 1
	dmg *= 1.08
	best_wave = maxi(best_wave, wave)
	_save(true)
	play_sfx("win")
	var victory_colors := [Color(0.77, 0.48, 0.83, 0.68), Color(0.43, 0.68, 0.77, 0.58), Color(0.91, 0.47, 0.29, 0.65)]
	for i in 9:
		var burst_pos := Vector2(randf_range(350.0, 1030.0), randf_range(120.0, 610.0))
		fx_rings.append({"pos": burst_pos, "r": 5.0 + float(i % 3) * 5.0, "max": 46.0 + float(i % 4) * 13.0,
			"color": victory_colors[i % victory_colors.size()], "t": 0.0})
	_float_text(Vector2(650, 170), "ДВОР УДЕРЖАН", Color(0.96, 0.70, 0.38), 28)
	say(["Отбились! Так держать!", "Скуфы, вон со двора!", "Тапки творят чудеса!"].pick_random(), "happy", 2.8)
	hud_hint.text = "Волна %d отбита!  ·  Бонус +%d монет" % [wave, bonus]
	_update_hud()
	_show_choice()
	_save(true)


func _game_over() -> void:
	_notify_yandex_gameplay_stop()
	state = "over"
	_sync_portrait()
	say("Они... забрали подъезд...", "panic", 4.5)
	play_sfx("lose")
	best_wave = maxi(best_wave, wave)
	_save(true)
	for c in over_panel.get_children():
		c.queue_free()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	over_panel.add_child(vb)
	var t := _label(vb, "ПОДЪЕЗД ЗАХВАЧЕН", 36, Color(0.86, 0.48, 0.50))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label(vb, "Ты продержалась %d волн и уложила %d скуфов.\nРекорд: %d волн · ⭐ %d звёзд" % [wave, kills, best_wave, stars], 20).horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var b := _button(vb, "🔄 Ещё раз!", 26)
	b.pressed.connect(_start_run)
	var menu_b := _button(vb, "⌂  ГЛАВНОЕ МЕНЮ  ·  УЛУЧШЕНИЯ", 19)
	menu_b.pressed.connect(func():
		over_panel.visible = false
		_build_menu())
	over_panel.visible = true


# ---------- Способности ----------

func _use_ability(id: String) -> void:
	if state != "battle" or cooldowns[id] > 0.0 or enemies.is_empty():
		return
	play_sfx("click")
	match id:
		"bucket":
			cooldowns[id] = 18.0 * cdr_mult
			var center := Vector2.ZERO
			var best_count := -1
			for e in enemies:
				var cnt := 0
				for e2 in enemies:
					if e.position.distance_to(e2.position) <= 150.0:
						cnt += 1
				if cnt > best_count:
					best_count = cnt
					center = e.position
			play_sfx("splash")
			fx_rings.append({"pos": center, "r": 10.0, "max": 150.0, "color": Color(0.4, 0.75, 1, 0.7), "t": 0.0})
			for e in enemies.duplicate():
				if is_instance_valid(e) and e.position.distance_to(center) <= 150.0:
					e.take_damage(60.0 * ability_mult)
					e.apply_slow(0.5, 3.0)
		"chord":
			cooldowns[id] = 30.0 * cdr_mult
			play_sfx("chord")
			fx_rings.append({"pos": Data.HERO_POS, "r": 20.0, "max": 700.0, "color": Color(1, 0.6, 0.9, 0.6), "t": 0.0})
			for e in enemies.duplicate():
				if is_instance_valid(e) and not e.dead:
					e.take_damage(25.0 * ability_mult, 70.0)
		"cat":
			var target: Node = _pick_target_in_range(Data.HERO_POS, 2000.0)
			if target == null:
				return
			cooldowns[id] = 25.0 * cdr_mult
			if cat_node == null:
				cat_node = Node2D.new()
				cat_node.z_index = 850
				var spr := Sprite2D.new()
				spr.texture = tex["cat"]
				spr.flip_h = true
				spr.scale = Vector2(1.0, 1.1)
				spr.offset = Vector2(0, -tex["cat"].get_height() / 2.0)
				cat_node.add_child(spr)
				add_child(cat_node)
			cat_target = target as Node2D
			cat_node.position = Data.HERO_POS + Vector2(-12, -48)
			cat_node.visible = true
			cat_active = true



func _spawn_guard(source_index: int, target: Node2D, tower: Dictionary) -> bool:
	for guard in guard_units:
		if int(guard.get("source", -1)) == source_index and is_instance_valid(guard.get("node")):
			return false
	var guard_node := Node2D.new()
	guard_node.position = target.position + Vector2(20.0, 0.0)
	guard_node.z_index = 200 + int(guard_node.position.y)
	var guard_sprite := Sprite2D.new()
	guard_sprite.texture = tex["td_granny"]
	guard_sprite.offset = Vector2(0, -tex["td_granny"].get_height() / 2.0)
	guard_sprite.scale = Vector2(0.68, 0.75)
	guard_sprite.modulate = Color(1.15, 0.84, 0.66) if str(tower.get("branch", "")) == "power" else Color(0.72, 0.88, 1.15)
	guard_node.add_child(guard_sprite)
	add_child(guard_node)
	var level := int(tower["level"])
	var hp := 65.0 + guard_hp_bonus + 15.0 * float(level - 1)
	var branch := str(tower.get("branch", ""))
	if branch == "power": hp *= 1.35
	guard_units.append({"node": guard_node, "hp": hp, "max_hp": hp, "source": source_index,
		"branch": branch, "pulse": 0.25})
	queue_redraw()
	fx_rings.append({"pos": guard_node.position, "r": 8.0, "max": 48.0,
		"color": Color(0.55, 0.9, 1.0, 0.75), "t": 0.0})
	play_sfx("chord")
	return true


func get_guard_blocker(enemy: Node2D) -> Node2D:
	for guard in guard_units:
		var node = guard.get("node")
		if is_instance_valid(node) and enemy.position.distance_to(node.position) <= 35.0:
			return node
	return null


func damage_guard(node: Node2D, amount: float) -> bool:
	for i in range(guard_units.size() - 1, -1, -1):
		var guard: Dictionary = guard_units[i]
		if guard.get("node") != node:
			continue
		guard["hp"] = float(guard["hp"]) - amount * 0.72
		queue_redraw()
		if float(guard["hp"]) <= 0.0:
			if is_instance_valid(node): node.queue_free()
			guard_units.remove_at(i)
			fx_rings.append({"pos": node.position, "r": 10.0, "max": 55.0,
				"color": Color(1.0, 0.58, 0.35, 0.75), "t": 0.0})
			return true
		return false
	return true


func _update_guards(delta: float) -> void:
	for i in range(guard_units.size() - 1, -1, -1):
		var guard: Dictionary = guard_units[i]
		var node = guard.get("node")
		if not is_instance_valid(node):
			guard_units.remove_at(i)
			continue
		node.z_index = 200 + int(node.position.y)
		if str(guard.get("branch", "")) == "control":
			guard["pulse"] = float(guard.get("pulse", 0.0)) - delta
			if float(guard["pulse"]) <= 0.0:
				guard["pulse"] = 1.0
				var slowed := false
				for enemy in enemies:
					if is_instance_valid(enemy) and not enemy.dead and enemy.position.distance_to(node.position) <= 105.0:
						enemy.apply_slow(0.55, 0.9)
						slowed = true
				if slowed:
					fx_rings.append({"pos": node.position, "r": 12.0, "max": 105.0,
						"color": Color(0.55, 0.83, 1.0, 0.38), "t": 0.0})


func _update_cat(delta: float) -> void:
	if not cat_active or cat_node == null:
		return
	if cat_target == null or not is_instance_valid(cat_target) or bool(cat_target.get("dead")):
		cat_target = _pick_target_in_range(Data.HERO_POS, 2000.0) as Node2D
		if cat_target == null:
			cat_active = false
			cat_node.visible = false
			return
	var to: Vector2 = cat_target.position - cat_node.position
	if to.length() <= 42.0:
		var center: Vector2 = cat_target.position
		play_sfx("boom")
		fx_rings.append({"pos": center, "r": 10.0, "max": 110.0, "color": Color(1, 0.6, 0.25, 0.7), "t": 0.0})
		for e2 in enemies.duplicate():
			if is_instance_valid(e2) and not e2.dead and e2.position.distance_to(center) <= 110.0:
				e2.take_damage(85.0 * ability_mult)
		cat_active = false
		cat_target = null
		cat_node.visible = false
		return
	cat_node.position += to.normalized() * minf(620.0 * delta, to.length())
	cat_node.z_index = 100 + int(cat_node.position.y)


func _update_cooldown_ui() -> void:
	var delta := get_process_delta_time()
	for id in cooldowns:
		if cooldowns[id] > 0.0:
			cooldowns[id] = maxf(0.0, cooldowns[id] - delta)
		var b: Button = ability_btns[id]
		var names := {"bucket": "ВЕДРО  ·  ВОДА", "chord": "АККОРД", "cat": "КОТИК"}
		if cooldowns[id] > 0.0:
			b.text = "%s\n%d c" % [names[id], int(ceil(cooldowns[id]))]
			b.disabled = true
		else:
			b.text = names[id]
			b.disabled = state != "battle"

func _float_text(pos: Vector2, text: String, color: Color, size: int) -> void:
	# Keep transient UI nodes bounded during dense waves / multi-target pulses.
	if fx_texts.size() >= 28:
		return
	var l := Label.new()
	l.text = text
	l.position = pos
	l.z_index = 950
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("shadow_offset_x", 1)
	l.add_theme_constant_override("shadow_offset_y", 1)
	add_child(l)
	fx_texts.append({"node": l, "t": 0.0})


func _update_fx(delta: float) -> void:
	var had_rings := not fx_rings.is_empty()
	for r in fx_rings:
		r["t"] = float(r["t"]) + delta
		r["r"] = lerpf(10.0, float(r["max"]), minf(1.0, float(r["t"]) / 0.45))
	for i in range(fx_rings.size() - 1, -1, -1):
		if float(fx_rings[i]["t"]) > 0.45:
			fx_rings.remove_at(i)
	for f in fx_texts:
		f["t"] = float(f["t"]) + delta
		f["node"].position.y -= 42.0 * delta
		f["node"].modulate.a = clampf(1.2 - float(f["t"]), 0.0, 1.0)
	for i in range(fx_texts.size() - 1, -1, -1):
		if float(fx_texts[i]["t"]) > 1.2:
			fx_texts[i]["node"].queue_free()
			fx_texts.remove_at(i)
	if had_rings or not fx_rings.is_empty():
		queue_redraw()


func _draw() -> void:
	# A soft ground shadow and halo separate the hovering character from the road texture.
	draw_set_transform(Data.HERO_POS + Vector2(0, 25), 0.0, Vector2(1.9, 0.34))
	draw_circle(Vector2.ZERO, 23.0, Color(0.025, 0.018, 0.045, 0.48))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var halo_center := Data.HERO_POS + Vector2(0, -150)
	draw_circle(halo_center, 43.0, Color(0.55, 0.30, 0.68, 0.13))
	draw_arc(halo_center, 44.0, 0, TAU, 48, Color(0.78, 0.56, 0.84, 0.48), 2.0)
	# Маркеры входов скуфов на четырёх подходах
	for spawn in Data.SPAWNS:
		draw_circle(spawn, 13, Color(0.70, 0.32, 0.38, 0.34))
		draw_arc(spawn, 21, 0, TAU, 24, Color(0.82, 0.48, 0.53, 0.75), 2.0)
	# Persistent sofa barricades are actual world sprites; only their durability bars are drawn here.
	for bi in barrier_hp.size():
		var bp: Vector2 = Data.BARRIER_POINTS[bi]
		if barrier_hp[bi] > 0.0:
			var max_barrier_hp: float = Data.BARRIER_MAX_HP[bi]
			draw_rect(Rect2(bp.x - 26, bp.y - 34, 52, 5), Color(0.04, 0.06, 0.09, 0.88))
			draw_rect(Rect2(bp.x - 25, bp.y - 33, 50 * barrier_hp[bi] / max_barrier_hp, 3), Color(0.76, 0.45, 0.49))
	# радиус выбранной точки
	if slot_popup.visible and slot_popup_slot >= 0:
		var pos2: Vector2 = Data.PADS[slot_popup_slot]
		var rng := 260.0
		if towers[slot_popup_slot] != null:
			rng = float(Data.TOWER_TYPES[towers[slot_popup_slot]["type"]]["range"])
		draw_arc(pos2, rng, 0, TAU, 64, Color(1, 1, 1, 0.35), 2.0)
	# радиус Альтушки — пунктиром у подъезда
	draw_arc(Data.HERO_POS, Data.HERO_RANGE, 0, TAU, 64, Color(0.72, 0.82, 0.92, 0.20), 2.0)
	for guard in guard_units:
		var gnode = guard.get("node")
		if is_instance_valid(gnode):
			var frac := clampf(float(guard["hp"]) / maxf(float(guard["max_hp"]), 1.0), 0.0, 1.0)
			var bar_pos: Vector2 = gnode.position + Vector2(-21, -93)
			draw_rect(Rect2(bar_pos, Vector2(42, 6)), Color(0.06, 0.1, 0.14, 0.95))
			draw_rect(Rect2(bar_pos + Vector2(1, 1), Vector2(40 * frac, 4)), Color(0.35, 0.9, 0.65))
	for r in fx_rings:
		var a := 1.0 - float(r["t"]) / 0.45
		var col: Color = r["color"]
		col.a *= a
		draw_arc(r["pos"], float(r["r"]), 0, TAU, 48, col, 5.0)


func _update_hud() -> void:
	if not is_instance_valid(hud_wave):
		return
	hud_wave.text = "ВОЛНА  %02d  ·  УР. %d" % [wave, run_level]
	hud_coins.text = "КАЗНА  %d" % coins
	hud_hp.text = "ПОДЪЕЗД  %d/%d" % [int(maxf(tower_hp, 0)), int(tower_max_hp)]
	hud_hp.add_theme_color_override("font_color", Color(0.82, 0.88, 0.92) if tower_hp / maxf(tower_max_hp, 1.0) > 0.3 else Color(0.88, 0.52, 0.55))
	_refresh_tower_controls()
	if state == "prep" and is_instance_valid(shop_panel) and shop_panel.visible:
		_refresh_shop()
	_queue_slot_popup_refresh()

func _run_snapshot() -> Dictionary:
	if state not in ["prep", "battle", "choice"]:
		return {}
	var phase := state
	var resume_wave := wave
	if state == "prep":
		resume_wave = wave + 1
	var saved_towers: Array = []
	for tower in towers:
		if tower == null:
			saved_towers.append({})
		else:
			saved_towers.append({"type": tower["type"], "level": tower["level"], "branch": tower.get("branch", "")})
	return {
		"phase": phase, "resume_wave": resume_wave, "coins": coins, "coins_earned_wave": coins_earned_wave,
		"run_level": run_level, "kills": kills,
		"tower_hp": tower_hp, "tower_max_hp": tower_max_hp, "dmg": dmg, "fire_rate": fire_rate,
		"ability_mult": ability_mult, "cdr_mult": cdr_mult, "run_coin_mult": run_coin_mult, "guard_hp_bonus": guard_hp_bonus,
		"shop_levels": shop_levels.duplicate(true), "branch_choices": branch_choices.duplicate(true),
		"barrier_hp": barrier_hp.duplicate(), "towers": saved_towers,
		"rewarded_ad_used": rewarded_ad_used
	}


func _save(force := false) -> void:
	if force:
		_write_save()
		return
	# Combat generates frequent reward/damage events. Batch these writes so Web/IndexedDB
	# is not synchronously touched for every hit or every defeated enemy.
	if not save_pending:
		save_delay = 2.0
		save_pending = true


func _write_save() -> void:
	save_pending = false
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({
			"best_wave": best_wave, "stars": stars, "permanent_perks": permanent_perks, "resident_jobs": resident_jobs, "outfits_owned": outfits_owned,
			"outfit_equipped": outfit_equipped, "sound": sound_on, "run": _run_snapshot()}))


func _exit_tree() -> void:
	if save_pending:
		_write_save()


func _load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var parsed = JSON.parse_string(f.get_as_text())
	if parsed is Dictionary:
		best_wave = int(parsed.get("best_wave", 0))
		stars = int(parsed.get("stars", 0))
		permanent_perks = parsed.get("permanent_perks", {"damage": 0, "income": 0, "hp": 0})
		var loaded_jobs = parsed.get("resident_jobs", ["income", "repair", "guard"])
		if loaded_jobs is Array and loaded_jobs.size() == 3:
			resident_jobs = []
			for role in loaded_jobs:
				resident_jobs.append(str(role) if str(role) in ["income", "repair", "guard"] else "income")
		outfits_owned = parsed.get("outfits_owned", ["goth"])
		outfit_equipped = str(parsed.get("outfit_equipped", "goth"))
		sound_on = bool(parsed.get("sound", true))
		var saved_run = parsed.get("run", {})
		if saved_run is Dictionary and not saved_run.is_empty() and int(saved_run.get("resume_wave", 0)) > 0:
			pending_run_save = saved_run
		if best_wave > 0:
			hud_hint.text = "Твой рекорд: %d волн. Скуфы уже точат тапки..." % best_wave
